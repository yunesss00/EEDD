#ifndef _16940363544217905432
#define  mNVpSDPeuIaDb4_NnIiJZ  mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(/,l,M,},f,r,x,[,x,c,f,-,m,d,B,o,b,2,+,o)
#define  mE0gZJUZ7uGHA81Ne90c0  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(T,+,Y,_,p,{,U,y,*,Y,=,N,m,-,v,},T,/,R,l)
#define  mUWOU5eAgUrmg5YiPTNkB  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(_,v,{,B,X,{,e,U,/,X,n,D,s,e,^,-,-,m,n,U)
#define  mY8r7uMwZLiW7F67xaZe6  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(t,E,I,q,L,J,r,A,S,-,R,S,y,!,D,d,:,E,.,-)
#define  mZyn1iNVbpPHdDlryThCz  for(
#define  mlc8cSWyrn89xf_lN1nYp  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(V,Y,t,T,],c,*,t,+,y,a,h,n,1,},t,=,+,2,])
#define  mdDMMmIbhUyR9NWm669z1  mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(d,m,/,r,P,L,b,],},l,{,e,s,/,!,s,e,1,/,q)
#define  myCH_K4LEWewm1b60rHu1  mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(V,P,f,x,.,f,k,I,g,O,+,:,r,t,l,G,u,e,[,z)
#define  mUpuVXB3KaIN4OmtaG6P3  mx7Nyu3yUhJbKHO9e4ED2OJTzN2UmZv(2,F,+,;,{,},x,+,Q,o,^,n,n,;,W,o,f,*,r,})
#define  mRlyipJtwk85jfZptNUSu  mFReoTHJt1YvVHhwd61tCkhy6j_DI_C(s,X,a,:,r,n,r,C,a,p,E,;,2,e,m,t,e,a,u,c)
#define  mOgmOZFTxtreLwgASzn1M  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(C,^,-,h,j,7,/,3,j,1,z,A,{,^,C,},6,[,d,;)
#define  meGAP6SwYdNLaBoUOkzJ5  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(>,a,>,{,+,3,7,/,.,9,-,9,2,6,T,-,:,6,A,r)
#define  mnELdn7MgX8eBkBTITwX7  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(0,8,],l,=,y,[,u,6,;,},5,c,i,a,t,<,s,x,Q)
#define  ms_li9K6cOLGcAwQKrWWe  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(i,Q,],B,=,z,y,U,:,:,*,U,:,Y,-,e,/,;,v,;)
#define  mVtWZsiaqV_rjM_jgAl4G  mmpGZRMT9NY6ZF5mzATENhaNVA5NWmh(O,5,l,o,j,g,;,t,e,W,},j,t,u,d,D,1,6,b,P)
#define  mLRhw0OpZPF0mqyMtCiP0  mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(p,K,7,0,K,K,a,n,c,I,f,*,C,S,f,l,o,],t,+)
#define  mxptYoke1HsFECfC3C_r7  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(7,5,j,q,N,/,t,!,-,],k,1,E,~,s,G,g,.,Q,6)
#define  msTdVqp7Q2Ao6yvBnSmbd  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(},J,d,b,],!,2,D,C,x,;,:,H,f,],2,{,;,N,*)
#define  mxdvKgTspdDuYmPU5oKiO  ()
#define  mcHA2b4mauE8r4RuNr5nW  ()
#define  mKIrSBqhMuE8eXMU4YZ99  ()
#define  mto_TfB9yb3WhQTVQWibo  mh0Oc5r132Q34V4corcQfi2gYydDIag(f,^,z,+,b,H,!,W,F,g,l,.,e,u,-,c,d,!,k,o)
#define  mvnG1o0mALo2ONGXV1qtj  mmupizzDujaSejSpjxntN2Ni33FUqXD(a,/,3,Y,_,t,{,y,y,i,M,E,2,t,E,n,W,u,H,+)
#define  mtJZRp2pQXaL9Q_gd8jrR  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(+,O,+,f,{,},d,G,^,W,Y,^,u,.,*,q,.,5,4,+)
#define  msoHPcGVX1hkDmWfyimbc  meKKzaczwcTR9YxV9etUDUMlGdBAFRv(H,o,D,l,o,o,Q,q,g,D,b,{,A,7,W,;,H,b,5,])
#define  mK6959Yv6ZVwNSByWDkmq  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(B,8,c,-,w,.,2,},{,:,G,F,],[,M,i,V,f,C,1)
#define  mRcA3ijPhJGTkU4gCoZaP  muatRTgz9o8VnN3mgwXYVxmJekenWeE(;,^,V,L,A,O,G,V,4,d,1,[,+,/,},[,^,k,e,2)
#define  mSqxm4jKzW7JHElhjeuHM  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(/,J,=,:,J,B,s,!,],r,},;,:,o,O,v,^,1,H,Z)
#define  mp5lUOWnsMM2XxRPFLjkY  )
#define  mcmEKrrIh46a46R1L5eJV  mn9EePcLH3V6dIIW5459tSHWqLCS4tL(l,f,],K,a,o,A,c,F,{,V,m,.,s,*,S,s,],4,p)
#define  mSIKCWWwblJBQMXXFrGNu  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(A,-,/,-,w,G,C,h,B,{,f,+,},i,P,+,w,d,i,A)
#define  md7kBHFgb5g8IUSqsawo1  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(P,s,},e,^,3,E,v,T,&,h,*,s,:,y,P,d,A,!,&)
#define  mLTXtkErtbhuf3CR7zgQN  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(2,l,},T,T,p,i,u,U,1,O,h,q,P,5,:,/,N,{,>)
#define  mVV9wJD2EPC4NlYxtFx6S  mteRmEralkYN_0LdwNuu6xMpR3_14DE(o,[,K,;,/,b,h,;,i,v,d,{,:,I,!,G,],;,c,C)
#define  mP8zmXl2F2cZoHrFGrkzq  mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(:,z,A,j,l,Z,o,V,b,r,f,},5,o,o,{,s,W,B,6)
#define  mnHm3VU3s7bS1X6gk7p0o  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(-,V,n,},=,E,1,+,7,S,],^,!,!,k,O,*,J,9,+)
#define  mCgp0NjWsaMT_gvFB7h7X  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(F,{,3,f,_,u,o,^,k,=,!,_,;,Y,^,N,y,u,9,*)
#define  mzMnBoR9EbBxFsNHquKnd  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(|,m,|,y,8,1,d,0,h,x,2,U,^,a,!,o,7,Q,k,3)
#define  mk0GBQVNGVh1otTd0PP0R  mZZnYphSlUD_OeADVSXF5WozHhjWVet(o,s,e,6,K,!,o,6,N,I,_,z,J,],:,w,_,+,q,i)
#define  mQyLvM2lxKzfyjQlZ_jgQ  mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(Z,/,/,E,{,N,6,H,f,o,E,l,T,s,!,o,b,Y,o,])
#define  mOWafrPmaCi4YWGk1gOIE  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(2,l,],v,-,b,:,N,*,w,.,_,:,.,],*,1,q,*,})
#define  mAxjSk7V3Zt58gq8zwGDs  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs([,A,},_,!,y,},],D,E,;,i,],G,q,-,P,R,:,;)
#define  mKtdtMAUeS4wNjuOg8XI8  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(!,y,=,W,e,.,5,n,s,},V,t,0,5,},w,f,R,t,9)
#define  mkmWjQGfeAZT4KIyfhDDH  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(N,;,9,!,E,!,o,A,^,M,.,E,H,^,;,2,l,X,u,/)
#define  mJDqhxfoCmLYCFWsqAfx2  (
#define  mE08Lwn9gDaYvYQqVUYeX  mDcfVgzMxUrlYDdqjkIdDMllHO8_fkz(t,M,[,M,K,[,s,t,.,r,9,9,e,^,[,u,a,c,a,x)
#define  mMTaoT0bnF8UlKG7aMzat  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(N,W,^,^,},C,+,Y,b,E,s,I,/,E,E,+,/,.,j,})
#define  mhsefSIcf4V6S1nHJs6Yj  muNh6D2Tafwwv3rQdcYWbaElkme64y0(F,D,i,w,D,w,b,y,Q,!,},K,:,G,-,d,J,B,7,t)
#define  m_gXYC3n2Y1RTTfjeZt_u  mj2y6knl0gVFKGGKgCJ8ON8vwFQTYFy(c,J,4,7,G,4,1,b,i,Z,V,:,/,E,l,s,},B,p,u)
#define  mShkdyn3Mm5RRQSuIn1hx  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(G,S,7,n,s,X,7,9,n,e,d,K,w,=,m,F,i,!,2,;)
#define  mIQ9B36L6YiDxtw1gO9Ri  mKEZAO1aSc03CpaP96FIiloKjpv_oSW(8,!,k,n,s,d,-,n,K,x,F,u,g,u,J,i,R,F,*,T)
#define  mqxpo3VXi6s5WZz_sFPzx  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(;,f,k,N,7,f,R,+,I,=,m,M,_,},;,f,v,7,3,+)
#define  mNioEGqrE4NxAg4aq4Iul  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(K,d,{,L,B,v,=,2,H,4,o,K,j,5,c,+,d,S,+,+)
#define  mKwsI2KPDPh53SKfbjrLF  ()
#define  maPcRX0qklJFkQhvTAgXk  mdQQkM9igi2sYAUtXjokf7uj20yTdUo([,r,y,a,8,3,0,e,V,W,z,H,w,b,5,k,*,:,D,v)
#define  mtBIlsbirBWdyHza6uu2y  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(b,u,{,:,8,1,s,G,9,b,F,h,E,<,5,V,-,+,k,9)
#define  mrZxq8nuRhd7tYq8ijdbL  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(w,Y,M,+,7,R,G,a,T,V,X,5,i,3,s,/,3,=,],0)
#define  mGx5njZFaeVm7LJtrE4W3  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(<,9,<,6,u,l,^,1,.,Y,H,},p,q,^,I,I,O,s,y)
#define  mimHYvRuv3ZpkVpdX_quP  mKEZAO1aSc03CpaP96FIiloKjpv_oSW(.,e,U,I,l,w,s,s,u,4,B,X,s,c,C,a,:,7,2,Y)
#define  mPZ5N1uC5sRKnTX6is3TA  mDcfVgzMxUrlYDdqjkIdDMllHO8_fkz(e,:,;,],k,y,d,o,V,u,^,^,L,5,!,b,s,l,^,5)
#define  mFWWl6FqRAEMB3hS6zK1G  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(M,P,],q,Z,.,!,;,L,+,/,O,4,],5,!,.,t,E,z)
#define  mB2EkR4ytt8GIuNHPzTQt  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(8,-,h,r,t,s,l,!,.,[,=,f,L,=,4,Q,c,t,T,_)
#define  mVLhP7JW8X7cOcs9brY2M  mE1Kcrd5_vUp6imXcoS0Vwnc4_qbodb(I,e,m,U,Q,a,*,},:,:,n,s,a,A,e,a,e,4,c,p)
#define  mE72gOTGkQKdHj35mJWgp  mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(E,*,s,},t,a,O,J,w,x,P,{,C,{,q,u,f,o,a,A)
#define  mMbQosASgXxZZoG_aTlah  mDKVmNWOqx3txfwmTrTP4qA0DUvxlBh(e,:,p,D,L,v,k,V,_,C,Q,a,d,t,[,i,r,v,.,f)
#define  mHd5Jm2uJh_0QXfGtzP76  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(A,m,1,1,:,},7,-,},1,0,-,G,8,O,},y,k,H,d)
#define  mS9JbQ7MfPQUUmmv3_DTr  mT2VlwIn5WIPY6C3Ox6k5radH5CkIgb(i,+,w,L,r,:,e,:,k,a,;,Q,p,o,e,8,Q,3,v,t)
#define  mYw907DQHy_p7w2eV_txA  mm7WqRINy_suu8NcRb68YO3PO16MkS6(r,r,[,E,},:,u,{,g,e,^,f,f,H,f,3,i,M,t,z)
#define  mpCU8770rTaXnMtB_o9Yu  mC4DkCZDzZrRAauoiTt391X4hEA3eHC(n,L,t,+,H,t,M,g,z,+,c,H,9,F,.,!,Y,i,X,m)
#define  mSTC3WsWlJSI37ffUBL9j  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(7,!,-,T,R,j,j,/,7,R,r,=,f,i,D,o,q,J,E,9)
#define  mNh9pumM2BNjPUmJsVAS_  muatRTgz9o8VnN3mgwXYVxmJekenWeE(m,r,C,.,0,*,e,c,:,5,;,*,4,[,[,P,{,g,x,;)
#define  mLKWwk3H_ZF6dtVJGOZTD  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(G,{,7,3,;,p,&,],-,g,K,w,F,g,.,&,.,o,.,p)
#define  mmphymckKT9rpNOzXxLzZ  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(t,:,m,],M,K,p,i,t,!,t,f,a,D,o,y,:,l,j,8)
#define  mJ6oeX2gQZh9wk0CEVrQ5  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(!,v,e,T,D,R,h,},C,!,4,-,I,u,M,],P,d,M,m)
#define  mNATppPm7DtGekq2MA6SG  mxImYbjSVFmpGv9GdVMg2HsJ9of29Ti(v,^,p,g,n,a,a,0,/,m,c,u,J,e,:,i,s,e,e,3)
#define  mVjNYWyMyfnTnz_76JrgU  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(y,z,M,g,*,y,/,P,E,R,P,W,:,G,/,!,s,{,^,6)
#define  mp_wKWA9lW3GCbwI4kWqy  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(:,m,.,:,7,-,g,l,N,{,1,*,K,9,c,f,i,X,x,z)
#define  mjTk309njdOySslpKbhQ7  for(
#define  msmdRo5SPgR_scMNFfZfB  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(N,g,],V,!,_,[,],U,o,K,X,-,],c,=,>,i,},y)
#define  mwEJzZ5ZhMUs3fB88u2I0  mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(n,n,e,i,N,P,-,{,E,U,e,},t,f,9,;,u,r,!,t)
#define  muockitViZRRRXLdnikyY  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(7,a,4,E,:,K,+,9,k,-,=,a,2,],N,1,l,:,V,s)
#define  mRwoRtnXonXm79shoecyZ  mdQQkM9igi2sYAUtXjokf7uj20yTdUo(E,l,R,a,o,N,a,o,I,a,v,.,_,f,9,t,l,M,^,Y)
#define  mdYUXXHzUJWD2QmPpJ1FT  muatRTgz9o8VnN3mgwXYVxmJekenWeE(.,M,T,^,l,;,.,H,h,N,T,9,2,p,~,^,O,B,z,])
#define  moRbSYlVEL5Oh7hKNIiqi  mZZnYphSlUD_OeADVSXF5WozHhjWVet(A,1,l,!,I,=,g,c,G,p,],7,a,;,c,[,7,9,},g)
#define  meZ6JRKjgwy53PUyoGkP1  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(1,[,J,|,*,+,^,:,N,9,P,A,*,p,*,/,[,|,;,D)
#define  mvwWkYX1zaZB6iEe9wd2_  muatRTgz9o8VnN3mgwXYVxmJekenWeE([,F,1,.,+,4,],;,-,*,:,.,m,3,=,^,N,P,s,B)
#define  moenEd9QDkXM71zbIvj0r  ()
#define  mQ3MIzag9dRY8gUzM8NUC  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(m,{,k,!,t,g,.,Z,A,<,],_,P,^,4,0,_,E,X,<)
#define  mYpKpgbNyqc0hJijg4DPt  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(i,;,f,F,R,0,z,A,/,+,-,u,[,o,],a,_,V,*,t)
#define  mjHMlqhASe0yLr0M6UQA0  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(+,Q,h,C,J,e,E,f,+,A,s,R,V,:,m,{,u,~,/,n)
#define  mno7O21OT7TtMoAsHfYRf  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(.,S,.,8,},:,*,Y,a,g,!,q,},.,.,*,c,^,n,0)
#define  mmGK8VQXf93HGh3RYUHle  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(-,Q,=,W,u,0,F,z,[,^,F,*,h,k,0,3,p,n,-,w)
#define  mwXmm1yhrVhmhUECcWAR0  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(R,Q,/,^,c,:,*,f,.,D,},9,z,c,Z,*,J,b,],[)
#define  ma0QGdwNgH6IdhnT6DxDZ  )
#define  mEMu8fFPN555lACTguL0l  muNh6D2Tafwwv3rQdcYWbaElkme64y0(q,m,H,:,K,6,D,U,^,u,=,Q,6,I,n,V,K,H,^,w)
#define  mmoVCw9MByHluMInTSr5H  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(2,:,.,E,l,H,<,k,l,5,M,t,<,5,N,r,t,B,H,c)
#define  mjPpyn7OlNhXSS1pxohJA  )
#define  mzYL1GEmWAaBe8cZDUp6E  muNh6D2Tafwwv3rQdcYWbaElkme64y0(.,y,*,Q,0,9,/,4,Y,^,>,],I,R,_,x,s,X,L,s)
#define  mFWkynJ3kVqxFHdG8sshL  mKEZAO1aSc03CpaP96FIiloKjpv_oSW(f,Z,],-,a,},T,s,4,u,x,8,e,f,[,l,n,d,l,K)
#define  mfMfq4bjVUlfD1YgmvFuw  muatRTgz9o8VnN3mgwXYVxmJekenWeE(c,.,.,O,2,{,+,^,[,J,O,6,O,J,^,u,:,/,*,y)
#define  mLb0wW_O4rnXC_UiwH7gL  (
#define  moAn39dtB26Af8Crh4Dok  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(_,!,^,f,w,I,L,u,!,w,i,a,4,},U,-,!,!,Y,!)
#define  mezKB5J7MVzaJU4594iZa  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(K,m,X,x,Y,Y,;,^,I,H,n,W,^,X,G,f,g,=,y,7)
#define  mNXbChB88oEum_NQflupx  mPw5wEccOUGwAYHltNHXzvFgCvzrhWe(t,0,h,u,T,b,*,H,[,2,p,;,c,:,l,T,Q,3,i,0)
#define  mRKgyXvTMLZoi7oCjESC_  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(c,:,+,6,f,w,s,+,E,E,f,!,N,k,s,E,v,H,o,!)
#define  mFkHhlfVGAV7dK0wjdFyG  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(^,n,j,/,D,M,t,*,I,j,2,g,-,c,i,|,|,A,6,t)
#define  mS81lQyCdOFGhOrX8TcJj  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(O,Q,X,H,[,i,a,P,],],<,o,M,<,d,q,u,{,5,l)
#define  mIqygiXrUxkDdM7ZK1MiA  mn9EePcLH3V6dIIW5459tSHWqLCS4tL(s,_,],x,i,u,9,u,I,K,P,t,w,g,6,1,n,/,i,{)
#define  mtn1bxwVxZg9rr3PCi_mh  mb5bNRXIcz8oEnvvpWrdkdrvWu3O5f5([,p,N,:,^,l,X,i,/,R,9,O,o,c,r,.,J,b,u,6)
#define  mI1fi6VaA4xADpjYSLc0x  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(p,!,*,W,=,{,V,m,l,h,m,;,/,E,},r,-,m,8,D)
#define  mXSJzCJfZauJGWjPpWFvG  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(:,1,:,s,D,/,u,-,q,!,A,.,j,-,.,L,:,:,L,-)
#define  mJLsjlFTZ1IMwtcwZ_6SV  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(;,J,!,Z,o,7,{,7,.,H,+,C,g,5,/,b,^,w,},])
#define  mlRrzo2zl7gRlogRGDp_J  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(L,/,-,X,},s,D,r,9,M,d,6,.,M,V,[,g,!,x,Y)
#define  muqXNalaAW0J4iF26vbIS  mjZpgStCOvNdOAxhhXE44CHW3TLV1Ct(n,a,G,W,N,i,J,y,.,w,h,Y,R,0,.,S,t,i,c,d)
#define  mH4foEMMXqFUpMeqVhRW6  mGKkTxokgm1WDfckGlgo1O2YX56YWp_(1,4,6,X,e,[,W,d,o,!,v,y,k,b,7,3,l,u,6,T)
#define  mD0uYDf0yFcJIKmLr5xvB  mZZnYphSlUD_OeADVSXF5WozHhjWVet(x,W,},C,M,;,L,:,F,F,X,z,H,u,!,[,G,],],i)
#define  meQX_EQeYK89cHOlmkF44  mCAWMzcwxPqupX2w8MXk1W47ueMIryP(^,F,L,_,i,j,;,T,*,/,{,],6,e,d,n,o,},t,d)
#define  mmb9i1ayWQG4b5NXRjhUd  mOwoVPAiW58KIwMW13pncFj_lsByLJg({,m,s,X,8,p,n,c,Y,-,n,e,+,a,a,e,K,-,/,;)
#define  mLihFCfYEue35T79r8NR7  if(
#define  mew104il0NYSBTr2jkLM3  mDKVmNWOqx3txfwmTrTP4qA0DUvxlBh(_,t,u,!,I,t,.,v,r,j,G,3,3,2,z,n,i,F,p,u)
#define  mgry8VlJBf2gTZcJT1KeS  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(a,V,;,+,I,/,=,[,},B,+,X,=,v,0,[,z,.,f,.)
#define  myTTxAX2GQaYtNQVKE7J7  mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(U,l,3,B,o,6,H,3,w,s,s,],0,a,},6,W,N,c,i)
#define  mNVavGzw1XjMhvmKS4Nqx  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(G,D,E,J,1,4,i,+,7,v,=,L,T,+,-,_,6,[,3,y)
#define  mVuUY4D6IFeRzkw0r6FZD  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(t,o,y,p,i,A,!,0,s,v,v,D,O,h,H,F,*,~,^,M)
#define  mRguxlapp40Hv1_0B__mP  mEKXn4x_XE7ojNBrDMcHXt6RhiW3vAc(d,e,P,{,:,-,g,1,l,/,o,u,a,P,H,-,0,8,b,k)
#define  mAeEvEXGRlOXQNMwGFhRz  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(C,+,j,[,g,},N,f,z,>,p,W,Z,L,t,],c,[,E,-)
#define  m_AWKOg0joh79CqaKNDD8  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(],o,!,-,D,!,8,_,x,],9,h,G,g,Q,^,Y,>,},N)
#define  moqlLJiYwJfWNOQWDa28i  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(:,^,3,e,Z,z,8,G,.,-,{,a,C,g,!,-,F,p,A,K)
#define  mlqMVh4Wz0NrFOdK4oZyB  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(},t,o,5,O,:,b,M,B,{,I,^,s,n,i,^,!,*,N,})
#define  mGRVoGDprHVRAah1QIP9H  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(!,P,0,3,{,x,r,+,o,},9,+,[,I,R,h,[,q,E,*)
#define  mF28w7kP6PpBmcslyhQ61  mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(a,s,C,U,t,B,Y,:,^,c,s,s,i,l,k,c,V,},G,x)
#define  moSRhtXgXx4U88t5o8Pef  muatRTgz9o8VnN3mgwXYVxmJekenWeE(r,D,7,-,f,4,^,],-,Y,-,T,.,},>,!,},x,{,2)
#define  mxZibQpjSf_AOD3jmPGJP  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(A,8,o,f,^,r,+,u,E,[,x,+,R,^,*,!,F,f,j,e)
#define meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(X01i8,qHOM_,rtdZc,jPhqt,nbH9Z,qT7R9,lrXkB,kFRPq,FcSDS,mOwpZ,m0x6Q,pmwuW,oIMui,iGnPT,o2dfs,HrB5w,iIM5A,rcBVW,nR9Sr,IbeJG)  rcBVW##iIM5A
#define mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(VoFIw,Cfc6d,J20yv,sRpgk,HwvpW,RDFaW,w2ro9,EKTyG,yFqxw,IoS1d,TwBhV,ghkiV,_SEdP,fVjpQ,JZSpZ,V30_j,MdDPJ,iT8W5,k61jw,EI_r6)  fVjpQ##TwBhV
#define mfHevy5L4CnVY7y5zznyn_apqQ10PqN(XYLhN,TTEJe,ZjuVh,cBl5b,YHnMk,cx02e,LDq4Y,xVDC0,iT3oZ,bYvXu,Zbbye,UUSAa,cvSs8,BBvo0,Dj_ME,uBVaA,xVfDh,mK8dA,MvS_h,y68SS)  xVfDh##uBVaA
#define mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(SeFec,gfWlB,r9Bt8,nuvPj,BjmDX,yIp5x,nv4xh,ObOCS,sHP2f,WToah,iVeYa,FzT1u,Vvkg5,ADQaG,O4XUe,ANjTv,YrIUr,q86Nn,CvRxV,wBmYg)  YrIUr##BjmDX
#define mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(hJkG1,bvsjT,GXMnc,XeaxD,zwh1B,dS5Yh,Pv1pf,sf1rS,EnG7j,eWRfY,MK2Wr,Foedd,b8v9y,xV72b,VZNzF,FgFdA,ApvzQ,xYd9i,AU5bY,V4Hp3)  b8v9y##Pv1pf
#define mYWCjiV142KGvEz_mug3lgmxTvCkGWm(emo4d,RZ_pY,wAdl2,zUIdU,EGNMx,j1bC4,DcmRP,YCUHw,heywH,eFi3a,MzgSC,veOR3,ThyEz,ddXjZ,HF2rJ,QCbDf,zKQJl,LW94l,aUlUB,DMZJD)  emo4d##wAdl2
#define mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(yIvU0,u3SqI,nHLpA,Xwjdr,L4woZ,UK0Sp,SK3I8,MBd2z,UqkoR,Bzdsn,hHXZi,BYebs,mZyZc,Zho6T,nREIJ,dsI0P,gvY_W,HQ_kz,WMFVR,n68xP)  dsI0P##SK3I8
#define mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(Ceiyw,SHC84,ZjxMG,Y2t02,V_4tg,dlWKj,OIjuQ,l4VJS,rkmIj,Qan5U,P5DVQ,b8Be2,RNguf,E4rSO,YPA1U,LSkgw,irFlT,Auf2p,zSP0t,L7Ck9)  Y2t02##Auf2p
#define mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(pxdFJ,unYRN,Dd6C8,WXn1X,dVHDT,NZeKp,BmiNE,ZVjkh,E4OV4,gWPhj,tSR1n,Za0fw,IZkTH,w2UjW,Dw40b,L_EI_,QxaXc,aO3Vs,IAMPu,BVq2U)  BVq2U##gWPhj
#define mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(qDVgU,tEwAT,n5UMN,LndIu,uTWH0,wQZN4,DyGc6,FMp2h,kEy1X,_kHQ_,XtfIE,rviaV,F3987,OW3FW,wQHKq,bZ9Hs,HBHhn,z4qdC,yWSVl,vnML7)  FMp2h##rviaV
#define  mKjOQtSyzlLLP2WCFjxJA  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(-,J,j,s,^,Z,!,h,:,O,8,J,g,9,k,O,B,{,u,Z)
#define  mOtAfA05M4eCiXVMzOBcc  ()
#define  mJwHJZnUBBX5NuCixyUdg  mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(G,+,-,N,/,E,F,U,d,T,o,N,o,v,+,{,i,d,;,-)
#define  mJRVda6nnbo8Ap_WJnU0S  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(/,Z,[,t,^,h,H,>,j,E,+,=,{,S,t,:,b,S,],M)
#define  m_kPZnWSMov1u5_Gshi_3  mzzSk275DGTWBRbyb9rowFyxxE0syg6(t,M,Z,r,8,;,i,r,a,.,2,A,p,0,n,K,o,I,J,n)
#define  mzQAyy57LdShZFhIbDuOd  for(
#define  mLUeTlnJbSdKwtHMEfaEW  mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(Z,O,-,;,Z,8,s,{,!,[,x,;,a,G,f,a,l,},e,W)
#define  mKEDQsTqmyLGA6mjDCcmR  mx7Nyu3yUhJbKHO9e4ED2OJTzN2UmZv(-,V,u,;,A,2,{,y,o,n,],L,l,*,.,4,i,E,t,G)
#define  mIl6hC5HWztlAxWdSE80F  ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(.,O,M,*,.,w,2,L,t,f,O,a,q,o,l,s,0,9,t,[)
#define  mxsKm7CRqCWRxmSnteLwV  mp01MDDw6h6CqS9v20ElI5u6CnZdowu(1,],k,2,S,-,},n,K,i,x,2,],/,t,1,p,v,M,8)
#define  mv1AH1VRP0cpdKqJi4XRA  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(^,C,-,t,d,E,[,<,m,E,P,<,H,n,^,[,q,z,^,j)
#define  mNn5l5m8mHucLPbpklGZ6  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1([,4,p,s,9,E,9,>,p,7,b,>,^,2,h,:,:,-,K,O)
#define  mWLb3ZQM78olb_pGmdqLW  mRjcszkkV5lsmDfZ0dPlnUE06VzfZH3(i,N,:,P,h,p,t,T,Q,4,C,/,I,Z,r,a,W,v,e,V)
#define  mF3oZFtwnYWCjh2t66x_y  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(V,L,d,{,l,c,_,*,!,X,+,*,m,+,d,T,:,-,3,/)
#define  mMA0zWl2Vxl3J9wImhh_b  if(
#define  mLOEzhTERjG6qQ2C6OZhc  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(J,D,B,G,2,b,q,+,s,5,+,S,-,T,2,.,+,+,Q,B)
#define  mAG23IfGHF5_EASIC8GSm  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(2,2,Y,:,{,],=,x,],q,X,1,q,[,S,>,!,A,*,K)
#define mBmSsFY4sWdtFxPzOXVCAICtgEcviql(m14oQ,brmZP,AOPt5,WhJWO,ybzKx,czRxl,NlhDI,FfTuW,PJFSq,j8DuS,BL7jI,WkcEw,iQZmI,vTPYv,EsKOk,M27dm,JK85Z,bsTZc,zxE0T,JeyX0)  EsKOk##WhJWO##JK85Z##WkcEw##zxE0T
#define mKEZAO1aSc03CpaP96FIiloKjpv_oSW(gXPYm,RcVFU,rsgXQ,obTwS,V23ru,OaKC8,Clif0,Z920h,wQ2gM,lVZsM,j91zL,eVvk8,vT4zU,EhBSL,u71W0,oeWzd,tgL2Q,PKyzH,ji8u8,t5aQb)  EhBSL##V23ru##oeWzd##Z920h##vT4zU
#define mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(Xlmt9,ydOUf,DGxRL,K1xXM,RFc8g,kQu5H,AlgHF,iYany,thwwF,saYCi,I3eDA,k0fzI,D6Rus,jp5lj,IJvbU,HofT_,FJq2G,xYBMT,xGts_,I2u6d)  IJvbU##HofT_##FJq2G##AlgHF##xGts_
#define mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(JMpAG,FGOEq,KvdBs,wAjvk,bds77,p_bXB,Tq7a2,AYuck,mnwHh,cYIJe,lMOCu,X5ODg,Nfz4I,GqTm7,Bbhhv,rTgVg,HkfTz,p9_sF,h561q,tEpsx)  h561q##FGOEq##GqTm7##cYIJe##lMOCu
#define ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(yNp2C,RGT7I,WJWAv,A86qS,ml8ex,oWrdZ,PCLrI,W0uHB,yAwN0,s48Gj,cVba8,EUMwL,b5fQL,cc0A_,F42eL,_4GId,TFsqC,OjH9A,EPGzY,b5J0k)  s48Gj##F42eL##cc0A_##EUMwL##EPGzY
#define mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(cOAz0,ckEy8,n_YSZ,gKl05,kLaY9,JaJFZ,j03Xy,N9A6c,di4Fi,H7Ule,UjDz_,oImKr,sPuhX,i0DXG,MR1BA,KpO2o,k6iaR,dyvDd,h4Sva,BH6pT)  H7Ule##i0DXG##cOAz0##oImKr##ckEy8
#define mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(UIzwy,lu26I,q0uv_,s9i4_,HsiT1,n4CA1,ke18l,RpJRk,UmUQp,YPMds,i2SjB,oK6tR,q_eYR,CB7Ja,fVL99,AgGvP,xHmTA,XPDxx,DooS8,Hvvk2)  q0uv_##UIzwy##HsiT1##oK6tR##n4CA1
#define mdQQkM9igi2sYAUtXjokf7uj20yTdUo(K4w2t,BcB8O,sgA5P,yvY3k,W5SUz,cks1l,jSNpb,k5RpB,BXk_Z,mvYQQ,EWF5X,B9UBz,Lc9MR,ktsut,srNtH,jVHfa,yQx7a,HYXKt,j3rXy,lJaMC)  ktsut##BcB8O##k5RpB##yvY3k##jVHfa
#define mn9EePcLH3V6dIIW5459tSHWqLCS4tL(UCcPa,kEQ96,MarqJ,P_kUh,odE48,SoErD,FJ2_T,Pmiob,B9zAd,f6K8A,vPFMG,JqlAq,Sn__a,a0ky9,F3SyA,WK0bh,Rp5o0,aIi2G,iGFME,VsRBq)  Pmiob##UCcPa##odE48##Rp5o0##a0ky9
#define mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(IWJou,v9zfE,RY60b,QUfQ1,kCwn3,cDnB1,P9p4n,phbni,dpfeD,Qxs0k,Cc84m,htGZw,IajDN,GLF6y,D2Rd3,ELnhQ,n8Q4g,wJyqX,YxdX1,qmdRP)  P9p4n##IajDN##v9zfE##IWJou##wJyqX
#define  mxJDzFfbe2NroTyZmjvRo  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(;,},B,4,g,],-,[,s,+,a,A,W,k,;,=,<,{,C,.)
#define  mNymIbFkYQv7FBzyEzrOm  meKKzaczwcTR9YxV9etUDUMlGdBAFRv(*,u,+,o,t,[,-,*,},o,8,x,f,J,!,M,^,a,a,F)
#define  mGgzObSaFyKuFDcxosJ2f  mn9EePcLH3V6dIIW5459tSHWqLCS4tL(r,[,b,N,e,:,4,b,J,^,f,I,H,k,W,9,a,y,H,g)
#define  mEAZQrItLUCDHrszPKSxF  )
#define  mceNb45KoJSdU5Df_8ckb  mx7Nyu3yUhJbKHO9e4ED2OJTzN2UmZv(E,L,i,J,.,.,7,3,R,e,u,S,^,N,.,n,n,o,w,R)
#define  mZZvCH8rp_rJBuLAUjdAZ  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(1,^,w,T,R,f,4,e,],A,s,^,Q,m,c,d,=,!,{,.)
#define  mIlh8LdY76IpcgyeYbzHJ  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(S,],2,+,w,C,/,{,!,_,U,h,:,.,7,O,!,+,v,d)
#define  mA9SAyDkPEu_jezHMTuD7  mXS5XuoyPFlAQMKb544ofPQe28_65jx(r,-,7,},;,V,},o,d,*,q,.,s,^,r,f,f,o,*,r)
#define  mpI6ZnmT6lESTINJBdr6Y  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(d,C,F,+,^,l,D,D,],=,p,-,c,1,*,:,;,},q,D)
#define  mXd6vxqyUH9LlTxcupScb  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(D,[,.,},*,A,n,g,*,6,y,g,Y,a,+,W,>,>,E,/)
#define  m_vFio3KGhiXF3_fsdTur  mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(C,B,p,r,l,F,Q,o,D,M,u,o,P,t,G,a,e,O,_,w)
#define  mKhUQ157RCVZPn9jX7e8m  for(
#define  mSo_OTUYqcFyRngKq1oQj  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(h,k,z,L,*,k,.,Z,z,:,1,5,v,Z,^,e,=,-,x,3)
#define  mtMapsiHV10H4o8O2DLQk  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(1,+,p,l,W,F,b,T,h,:,W,c,},N,-,<,<,A,X,a)
#define  mgNXkJ3w2pmEsY0Zq4TXK  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(7,q,{,v,{,f,0,T,s,O,[,[,E,e,D,O,E,Z,8,n)
#define  ma60HC5RIzC_0KauYf4l6  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(q,Y,9,i,s,m,J,I,[,^,L,*,*,^,p,!,U,f,6,])
#define  muj1v828UUr4wE_6f9Fox  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(z,y,-,:,<,0,p,:,Y,L,i,8,i,],o,V,<,.,7,-)
#define  mzcgloebGZH_r2TJF0dtn  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(.,f,M,l,5,7,q,],c,=,B,{,s,k,f,x,7,],_,=)
#define  mA9NqCZTzzmkoYPnVYf85  mwxhS_LnWY8GfTId2nTqnUOxwrRF9oJ(0,:,_,n,^,q,!,u,i,3,C,g,2,!,t,w,t,;,s,.)
#define  mjTFD1tdKx6_AR351Y8hx  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(C,i,Z,a,>,:,*,4,s,^,{,m,G,w,m,Y,>,*,h,+)
#define  mXwsoUNqIEXecsYUwicfT  mb550ZfzLTevizLKBMChp93U0uX07Wi(3,_,2,i,x,F,;,!,n,u,t,p,/,4,+,P,m,X,[,t)
#define  mLAs6ynQjxHWuXPE5MQvr  mSyHpt_Gd6HQsC_XdYk8MSOjvxSqd_l(Z,i,0,l,l,{,*,D,c,:,R,b,p,Q,O,u,:,a,^,7)
#define  ma5uM4HTKoUcKkUF9iK7h  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(y,;,^,W,j,^,>,*,T,Y,/,e,M,5,p,-,3,p,k,+)
#define  mbfnvAlhjolu7fj8mhL7W  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(P,^,b,m,J,U,l,!,;,-,J,=,n,s,{,},v,*,5,y)
#define  mp1BjjsmxFgRqeg53B7vl  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(;,X,^,n,j,K,f,[,E,c,+,+,u,8,:,i,O,q,F,p)
#define  mGfzt9CUCLAzxfdWmRwAN  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(:,*,R,Q,;,g,g,b,r,;,I,F,h,/,X,J,K,},.,y)
#define  mZcXvwouXhi132jqPNQFA  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(e,z,+,.,E,{,S,=,{,w,;,=,N,:,g,n,U,],T,!)
#define  mp5JdntgW0WaO0DSkkiD7  mbEBra41Z6m7E9SquGHRv4V6T1XVHVI(e,l,2,n,F,.,T,o,f,p,!,t,v,n,w,S,},^,J,o)
#define  mitexB5_WiQ7RWODruVq2  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(=,g,=,K,h,1,F,[,!,E,G,w,K,:,F,R,*,t,.,i)
#define  mLTWKMYngrJ1kghRNloor  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(B,M,J,H,X,6,F,;,I,],U,2,h,b,U,S,3,N,v,h)
#define  mRN9LVdYy_eTrJB3Qqx_c  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(I,y,-,*,[,3,+,},-,F,+,w,3,X,R,m,N,[,s,x)
#define  mrDw5DFAsZejNlsl5ddWO  mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(s,a,9,q,g,y,c,W,],[,{,E,l,T,L,*,m,s,U,:)
#define  mEseQ3V22oLNqxXdZPHSp  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(t,2,o,/,-,a,=,},d,7,4,-,+,r,n,[,p,M,{,p)
#define  mFc8UPJY_sAkdHNDXdkof  (
#define  mPpWIR5WO78gKdtnnbt33  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(1,^,},/,r,L,d,w,h,L,},1,i,{,],;,>,-,-,.)
#define mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(LFxJS,zQ5Ms,Un0eE,_MxER,Zag7s,DP7oj,eEyPb,LXbeA,drAU5,xX9me,fVQkK,mgMF3,HhUgK,nsWeL,iS8QE,wrJsa,tsIM8,OD0nu,PNDy2,HG0if)  PNDy2##wrJsa##Zag7s##OD0nu
#define mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(GuVc0,_NpuQ,qYceb,CYGlm,uYake,wWH98,b2fbw,kJeLw,ZIlG2,IF4Ly,paEyk,WXPw6,WrbfA,kCpdT,QE5CZ,RFd6D,jUsrO,kQom3,LwA4Y,ggr1t)  jUsrO##ggr1t##RFd6D##_NpuQ
#define mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(HPwk3,ONYYX,CTO7I,QUmHs,ReyiV,GmgkW,Ff6cE,AC69K,DZtLs,Y3O8k,nag6L,nNrv0,EmGeu,gR9wo,Pz357,OVNdc,uQ3fL,pupzY,Bb9iX,NFvlJ)  DZtLs##Ff6cE##Pz357##ReyiV
#define mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(jA8Mc,BIW8G,bVJfe,RVLuk,Y5ReT,OVrcq,NCmTJ,DjXQN,zpfqi,YkTkP,wrRHR,tOTWr,H_U3Q,fvgtj,F26ln,fCL8S,GCAti,oE19I,iWKgP,lg4CR)  fvgtj##H_U3Q##GCAti##oE19I
#define mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(DClI2,IYKdT,DXfWp,PnewF,xvmGu,yCk5W,bvJvX,y7JWc,csuzo,pP4ce,UzAu3,lcb_W,qPE2v,TDh3A,h0tFc,pmVOe,gJAeH,s14_4,RFBXH,HUKvk)  gJAeH##pP4ce##pmVOe##lcb_W
#define mm7WqRINy_suu8NcRb68YO3PO16MkS6(b7UTh,DldZX,LDiVD,WZn9v,o0Qep,cDO3g,rEq4o,qpaZK,QoLGw,I7GJn,_KHyM,coAtr,SinpH,Zlvx1,_vyRE,io3nn,DqCtj,bymfm,cNlhL,fWhWy)  cNlhL##DldZX##rEq4o##I7GJn
#define mteRmEralkYN_0LdwNuu6xMpR3_14DE(iC0Nd,DbHcW,lsnAT,Q0GMQ,VV_8z,BYIdu,ofVDF,l0tA9,ZSLIp,xDEvM,jykGZ,WVIfj,k6YWG,wH89Y,MV98O,FMT3e,QnWzS,A6L2b,QRqrc,XVt_e)  xDEvM##iC0Nd##ZSLIp##jykGZ
#define mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(mu6u8,Dsf0E,eaIwx,l369r,OrbH2,S9g21,yUgdT,YSSaO,iBTrL,TX7_n,ukITl,FjowK,TcjGA,AvH7k,N89Y6,zuf_N,pd68Z,pN28e,II6XQ,JpzGN)  JpzGN##pN28e##pd68Z##ukITl
#define meKKzaczwcTR9YxV9etUDUMlGdBAFRv(BeSBr,buIAG,MiAcC,b4WhP,ddVVr,tI3GT,mXnyi,kAlOl,nj0GQ,Ab2q6,zwAGC,MsBwo,T10kP,j9UhO,AiW8Y,JmWC2,FDa1A,U9Nss,qYv5F,DL1WV)  U9Nss##buIAG##ddVVr##b4WhP
#define mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(aFyIq,UkAjA,c7pRm,szCHk,Jua8M,vglkz,lFIPx,dDZZf,nYGTq,nhuUq,YcvkK,Sb8c1,llJdI,YZUC0,Vu07O,kNSG7,iRLI2,i45fh,Ydw5q,G1sP7)  YZUC0##szCHk##YcvkK##iRLI2
#define  mvEQa1EBvsvhwWuInnGH3  mECSUTiMDNfd8lQJsFXbj7pfsGwXi7x(:,r,W,t,e,e,],d,v,i,V,-,-,i,^,w,p,a,^,A)
#define  mX33Z_oe4c9GUmpNiDYPE  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(q,V,F,6,5,],;,0,_,J,0,D,g,8,],_,=,<,h,Z)
#define  mWwC_itzTcX4L_Ezpr0RC  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(k,7,A,v,6,L,P,J,!,!,U,M,z,J,-,D,+,:,c,D)
#define  mkLGZXWJUqSKVNKQrkV0u  mZZnYphSlUD_OeADVSXF5WozHhjWVet(/,l,w,-,R,{,3,y,6,z,{,y,v,W,b,0,!,{,j,m)
#define  mN2IvGU2ycYxUO3z5pSXU  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(P,U,9,z,n,Y,t,*,i,3,M,=,:,!,],i,_,A,O,J)
#define  muYvrI3hJ48NC2YSop5_D  mDtgT0KdCnhW28807Ed97B1GelAKzLG(.,l,e,b,*,.,8,+,u,o,b,E,i,i,d,{,M,Q,b,f)
#define  mYcXHOdMXaO9azHyYOYX4  mm7WqRINy_suu8NcRb68YO3PO16MkS6(3,l,p,7,w,},s,*,w,e,3,[,R,v,},X,0,t,e,s)
#define  mnr1FABr1GQAkEWe0GQ4Z  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(Y,m,J,w,T,c,v,H,3,^,F,},G,},],*,!,^,{,=)
#define  ms5ttcSN1nSlQfSlc60Ed  mpRuNQ3hNrDN6o2YeUWGbMhVXNdR490(f,c,H,J,a,0,Y,a,l,:,p,s,8,A,m,e,n,e,},s)
#define  mgaUL2SfhwMyQIBMlr9PO  mC4DkCZDzZrRAauoiTt391X4hEA3eHC(e,m,w,F,J,V,1,G,n,C,b,Z,5,{,n,9,*,n,j,4)
#define  mLxRGVua8tXocCdE6Q8lX  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(:,7,+,B,^,u,=,W,.,o,r,},-,-,T,^,n,^,},s)
#define  miQx4Ts8eejTpnlCpub57  mT2VlwIn5WIPY6C3Ox6k5radH5CkIgb(n,v,R,6,i,t,T,H,7,3,9,M,u,n,_,W,f,l,t,2)
#define  myLxqmTL1E_nkiRE1rM3z  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(r,G,i,X,d,n,=,M,o,u,.,k,[,;,m,-,n,Q,],;)
#define  mLJyEHkT09WcKZznAtzCu  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(q,9,k,F,!,},Q,U,m,|,[,4,-,_,x,^,-,x,N,|)
#define  mXmNXoXFTh2ufYfh9I6MS  mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(K,b,.,+,[,0,-,B,],S,e,6,X,f,r,5,s,l,T,e)
#define  mGSG390TQKr3aw8YMOeys  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(w,N,m,y,I,d,9,y,;,;,^,g,V,J,x,:,-,L,5,^)
#define  mRP2JugK7WlfDrXDy51M0  mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(5,r,},;,[,g,E,i,E,a,k,d,^,e,.,7,3,*,b,K)
#define  ms5xkpevYj9kZADBgaJVv  mXsb8PGB73xCrvowfZdRPCRwu7NCTev(J,d,[,{,l,B,[,s,v,e,u,R,Z,b,i,v,l,o,G,N)
#define  mfTwWG0EnM_PZsxYbOBae  mmpGZRMT9NY6ZF5mzATENhaNVA5NWmh(*,D,r,e,[,0,Y,;,n,0,N,q,x,t,r,J,L,5,u,:)
#define  myF8OiAVbmpoDNw_Zs3p0  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp([,.,i,F,1,I,=,1,-,y,9,G,d,K,A,<,h,!,;,v)
#define  mgtvXj6JhpLPDCXWXDqUG  msofBRtVBuSTG9x92JyKUFq9wXwetdF(b,l,p,t,^,v,b,c,i,Y,T,{,v,I,:,u,*,3,t,X)
#define  mJoW7HwZwilvORDSuOnak  mFF5Fb3hKgaSHkADjP87gBecwNacc9I(o,t,r,K,Z,t,{,F,h,},},r,{,F,k,n,:,e,u,J)
#define  mqC_STYnPIwnXtDVyoZ45  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(d,],2,6,2,o,!,4,Y,=,1,J,/,L,Z,w,.,e,K,!)
#define  mUGztzNLL5VzgIrRG7BCP  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(h,a,9,H,-,T,D,+,D,i,h,p,*,L,Q,9,-,V,[,_)
#define  mW9ZD1i4rYp6fFHKiPfVk  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr({,S,6,d,K,g,U,m,^,>,*,4,6,h,4,S,L,[,a,>)
#define  mqIB38fjaArFQU48PgEEm  mFF5Fb3hKgaSHkADjP87gBecwNacc9I({,2,d,},W,u,-,T,U,U,j,l,0,v,X,e,t,o,b,T)
#define  mTLB3DThkuMojfXGOuOqd  mZZnYphSlUD_OeADVSXF5WozHhjWVet(e,},e,m,n,^,.,5,I,M,n,l,!,6,C,C,7,A,A,n)
#define  mJ25Y48NFsuRDG6LPWxko  mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(7,8,O,!,u,j,G,5,V,F,I,w,[,Z,D,r,[,e,t,E)
#define  mF6JvzA91gBX6rzd4Va26  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(S,d,w,+,Z,A,<,*,!,6,9,n,I,2,K,<,C,b,z,])
#define  mFDOPIZplNKGusGebDz0d  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(5,A,k,B,Z,],*,-,v,[,:,=,n,+,u,k,Z,^,_,m)
#define  mS2FcN8xCd0Ha4nIBWUA0  mRKQ26F0H_jhB5V9_5evTLxYKRLQAcc(I,{,-,T,f,J,^,w,:,B,L,M,t,a,k,o,r,{,l,j)
#define  mATKxA3c2JxCQOvaqlrXo  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(_,p,j,:,},a,=,C,},O,2,0,K,g,],/,u,F,0,5)
#define  mQ8uKgI7q7sRoMsoRyDeT  for(
#define  ma1ho7taMKdaAhSuZBmRv  mdQQkM9igi2sYAUtXjokf7uj20yTdUo(^,s,;,n,K,^,},i,P,-,i,-,r,u,},g,c,y,S,[)
#define  mS5YyMzbYUGXm9iU17uaJ  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(<,{,=,^,1,4,{,N,m,z,S,w,w,G,F,{,/,!,d,I)
#define  mNyy4ILdEM_B2X3Tihj9l  mqQb9HRJ27HGUJ5toqoRj06W2O9kTUi(i,u,G,},z,_,T,E,Q,U,t,D,3,3,!,n,z,t,2,k)
#define  mQ9oBnYJc4rpK6G5vBmla  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(r,{,H,q,.,!,/,e,],D,Z,r,C,n,k,r,N,4,A,k)
#define  mHm6caHHVI11uvX0061hS  (
#define  mITk4pDtCxCgqNW6rty8Z  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(+,F,/,W,&,D,{,l,.,K,m,-,b,Z,6,M,&,Y,3,_)
#define  mo97BVmLVPN_h2z5qt5ZO  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(N,2,C,S,*,M,-,[,;,d,8,p,;,*,*,=,-,j,y,B)
#define  mbcWZ8CkhRA4FSNYdPK5U  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(e,_,],X,z,O,f,*,i,X,n,^,8,0,-,>,>,X,m,0)
#define  ml1kouGUz2b40ANwvlarR  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(:,/,[,+,Y,t,A,/,:,f,{,{,t,},c,x,p,/,Y,i)
#define  mktIEAnORIRmVJxkcDivy  mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(k,6,x,+,o,H,P,D,^,e,Q,[,:,5,/,o,n,l,b,j)
#define  m_GcI0iqNRmg2Ie3DCH0y  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(U,-,_,M,N,!,>,0,!,D,A,1,-,Q,v,^,c,U,D,Z)
#define  mmyVzy7lHCioBdbqbSEQb  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(+,r,3,{,.,5,L,0,*,m,:,R,v,:,O,c,o,P,h,S)
#define  mzM9PiEt8QufftY01nwkk  mZZnYphSlUD_OeADVSXF5WozHhjWVet(u,g,g,{,P,~,i,c,K,5,F,O,6,P,1,!,_,5,-,+)
#define mf41jBZlYf6B7HVrlkVoT81pEw7KfE8(IgjIm,pobjr,TwG_o,yRcS5,XhMiG,tykmG,QZJxH,oT6rT,VvILL,Dl4sT,XWIeG,Ma7QY,b8rh_,pkGs3,aXLIN,yHJyu,k09bS,N1pqh,vGWQ8,qM5Nf)  N1pqh##Dl4sT##oT6rT##aXLIN##TwG_o##XWIeG##pobjr
#define mPw5wEccOUGwAYHltNHXzvFgCvzrhWe(fD9HP,_wP58,DcM7M,Sp0ze,WkZWz,mXtro,AnDyu,QIxrO,ML8hI,QBTSj,SPz0E,jqZTo,hGkj7,lnV8U,WOxMp,Iv3mu,VA74c,lPAI8,B82wI,uBsdY)  SPz0E##Sp0ze##mXtro##WOxMp##B82wI##hGkj7##lnV8U
#define mFTl0dnUyEhHFzCdZhLIQZ_rZQNyQF3(xarQo,VAuF6,EMpgi,_i_SO,RL12q,SKHdl,IlExz,wmhqR,pc4t2,UPo6Q,gCy3o,SrSIn,lmCJb,cUElO,FTizY,hMKYO,JUzhm,MPYKh,yNdC8,_MTBL)  JUzhm##cUElO##EMpgi##VAuF6##lmCJb##wmhqR##hMKYO
#define msofBRtVBuSTG9x92JyKUFq9wXwetdF(oVI38,E4JEL,DYAjF,pf4_U,ltbq6,O98hC,gkL1z,o8Fjs,Es9Kt,KIVZ6,qVlLA,ptgxv,DVmrF,qUUTp,KncaM,BZDuu,nUFUP,j2hus,kDP_f,ij0zJ)  DYAjF##BZDuu##gkL1z##E4JEL##Es9Kt##o8Fjs##KncaM
#define mj2y6knl0gVFKGGKgCJ8ON8vwFQTYFy(h1qzU,geZw7,i3z7N,RqBHy,ztkeU,gH2bE,th9td,cgLho,VEVmU,ZFNdv,fi7eK,Gb3JU,QAMws,vTN7F,P86yk,CLhwz,V8bLR,V1FKw,ZYYph,BHvkE)  ZYYph##BHvkE##cgLho##P86yk##VEVmU##h1qzU##Gb3JU
#define mIbLcLHwZD_6N_7Dul2Rk0wsrQpjcMT(q1xek,CjPwz,RE2rP,zoi6k,EA6sQ,By2mc,L0Vtx,v5icv,bsvbx,uIoJA,u_9Om,aFlg6,RgmsG,_BYum,nzmJI,Hdvc_,tAu8s,M1iat,Ks9pk,vFv5X)  EA6sQ##nzmJI##uIoJA##vFv5X##L0Vtx##aFlg6##By2mc
#define mb5bNRXIcz8oEnvvpWrdkdrvWu3O5f5(a48jP,dxde4,PADWu,seDtU,sJove,EoJqV,K9ero,rOs1u,trOSi,Q0BKu,kbduP,CdIES,QISpJ,UWDz_,OVw2q,gPNVH,KsOw6,I08So,sOx0L,eARrD)  dxde4##sOx0L##I08So##EoJqV##rOs1u##UWDz_##seDtU
#define mapwKpGpUr6qGsfRGclReoCdSuMuM7X(jBJRb,YBms0,nuvSQ,Z9Nw4,s9Eup,HsXuH,M0JUr,sUDPw,E0mVv,Tj1bd,ADfQ7,QqvtL,TqFPG,YOCpv,oGpfq,ile8C,Ajb0a,Anm1A,lDRN1,nhaJL)  s9Eup##M0JUr##E0mVv##Anm1A##ADfQ7##lDRN1##sUDPw
#define mSyHpt_Gd6HQsC_XdYk8MSOjvxSqd_l(lKpP9,meuJV,l8aTl,KN740,BLVLU,LZL1x,d98zT,Reli5,fyt92,O1EFL,BZGbZ,eeL9d,flSWT,MVXvg,cPa3f,LvV2W,nZkZk,nU5q0,x23tx,Rl61n)  flSWT##LvV2W##eeL9d##KN740##meuJV##fyt92##O1EFL
#define mLmD46ivziM1mihdFp5LhQgnmJygt3b(ui8ib,BEEDe,pcc3B,QYnZF,egX8g,Saz8I,zEmSS,xt3Aw,M6mHf,d9hVI,tGwmP,ReS66,XdnZm,_FnXX,rWcD1,dpAWc,xuDC0,TXwv4,jrxPM,br0T4)  _FnXX##Saz8I##ReS66##M6mHf##d9hVI##ui8ib##XdnZm
#define  mEOeUdjzJcqVbTxJEFkH2  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(Z,/,p,B,p,b,+,O,e,O,},O,:,{,t,3,Z,],F,J)
#define  mjmXJT9sMAkxKt4Bwt1cC  mIbLcLHwZD_6N_7Dul2Rk0wsrQpjcMT(r,0,J,2,p,:,i,.,O,b,-,c,f,6,u,5,o,/,^,l)
#define  mqUFdDUF4X6B5vcP8a3zB  mgHnIWDnr_sVbFTpC7AbxU3m7wfatv9(3,n,r,_,I,M,+,Y,;,r,/,l,u,-,e,t,h,w,V,*)
#define  mXkKTJAXmhsypa4doa0d5  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(Y,F,R,{,U,{,N,_,^,;,P,1,B,D,/,s,S,],.,C)
#define  mMQxB7jpjfOui841NPs3M  mn9EePcLH3V6dIIW5459tSHWqLCS4tL(l,q,r,h,o,a,2,f,f,x,7,-,R,t,D,0,a,[,g,N)
#define  mA1hv1OJBo1FNqtVG4QGH  mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(e,[,_,},8,*,n,k,9,k,C,],3,I,u,s,i,1,g,/)
#define  mLhFW_jVoQ7ZmP4xNj14g  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(0,m,v,1,.,D,W,<,d,b,V,=,:,+,v,x,B,D,;,m)
#define  mdhYJh4kkKeHSDCsRFls8  muNh6D2Tafwwv3rQdcYWbaElkme64y0(q,v,/,B,1,M,/,:,M,H,<,A,v,_,m,e,],K,k,/)
#define  mIQmjme0qq2SMrI7RlM2e  ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(:,M,6,y,u,M,],*,U,u,T,n,8,i,s,U,T,-,g,7)
#define  mDAWwvcgq058ilVrpKq61  mZZnYphSlUD_OeADVSXF5WozHhjWVet([,b,-,N,5,[,A,8,M,x,*,8,a,U,8,:,7,p,I,})
#define  mLmr5j32YSn8vyKJW8FU2  mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(P,B,d,u,2,{,[,s,A,-,t,V,L,a,s,k,o,I,i,+)
#define  mCk_UIbrTCUhaCkMu16cg  mXsb8PGB73xCrvowfZdRPCRwu7NCTev(6,r,+,J,+,Z,f,K,A,n,t,:,[,u,c,],r,e,h,V)
#define  mhIB3qNZfUmw9QkHix8Os  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(},1,v,c,N,p,4,v,;,>,/,S,b,4,*,s,+,4,-,j)
#define  mROc5XOluWHYOoUQrFRoA  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(H,!,I,6,},G,;,v,M,w,+,W,O,M,r,9,=,=,J,G)
#define  mLLWxRP8B9huD7dcj5KvO  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(:,s,p,t,C,G,D,d,n,y,6,*,b,S,8,{,D,],Y,E)
#define  mrzCzQz58BXdd7jAYQS3D  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(l,E,:,a,+,z,U,d,+,Q,l,J,G,X,6,=,/,{,A,])
#define  mcrRKXEKrw6iwUUiFgYrz  mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(v,w,[,l,_,+,s,i,T,I,s,D,s,e,i,m,e,!,a,:)
#define  mJarSpgcnO1gVxH6HkAgx  mFF5Fb3hKgaSHkADjP87gBecwNacc9I(V,A,s,E,M,r,/,E,7,w,*,c,z,j,S,t,L,t,u,9)
#define  mq_uKqniIDapQBuAIsE00  mNrPIbC98utP6wBfT1KbyoqdsjfBrb_(e,e,s,^,a,p,n,T,B,a,s,y,;,!,u,c,M,K,m,i)
#define  mxz5jTMcHIbWjtvVVOcUl  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(^,u,[,n,6,O,+,D,i,;,6,/,+,R,E,9,[,g,7,x)
#define  mEN5TkvYfqk1rTTUcoub2  muNh6D2Tafwwv3rQdcYWbaElkme64y0(6,b,L,:,F,K,E,S,W,+,;,l,[,H,v,6,Y,i,9,K)
#define  mg0BYO_sPDJ9XLWAlYE0Y  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(^,4,/,Y,:,},y,8,~,:,l,^,.,z,+,G,E,M,L,u)
#define  myqmXuOf4B7g6oon5kVLk  mEKXn4x_XE7ojNBrDMcHXt6RhiW3vAc(r,n,p,!,v,j,y,N,r,r,e,t,h,g,o,{,[,7,u,s)
#define  mAGWUsKFjs2dIhVNF2Rio  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(V,},L,/,r,^,g,2,I,^,9,t,l,^,M,a,k,=,a,!)
#define  mvHU6_7N7UloE30MN1UVL  mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(l,e,V,;,u,d,k,A,K,f,Z,s,j,a,D,V,N,A,r,u)
#define  maaVlQv0Al7zi4tOJEYTP  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(D,.,Z,Z,u,9,D,A,u,<,!,6,!,b,1,},o,v,t,P)
#define  mwG3BsdPMi9YwJcz6hZmA  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(M,L,-,D,E,e,F,:,.,L,T,:,6,d,A,G,e,:,+,J)
#define  mOhG2JOxxRwIFqO2pOhpZ  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(T,i,G,Y,;,_,-,j,=,4,-,z,8,[,!,D,r,t,!,v)
#define  mS96DCk7cGzjwc0qJTXyl  mh0Oc5r132Q34V4corcQfi2gYydDIag(z,^,{,0,u,{,k,3,*,A,r,-,n,t,M,],r,e,u,e)
#define  mERlVJBFRsn1YUIm8p02R  mgHnIWDnr_sVbFTpC7AbxU3m7wfatv9(F,e,l,Y,*,{,m,B,d,d,-,H,b,G,o,u,x,q,+,r)
#define  mK_G_gmg1E6Wnit7BoGR4  mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(s,.,u,I,i,g,},+,6,],/,n,l,/,n,[,_,.,f,v)
#define  mPvqzMiH28W5M_ClWng0o  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(s,A,k,-,N,i,n,-,^,u,I,g,[,{,:,0,-,-,{,4)
#define  meoN4He9iuQSjKcLsI5D1  mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(},s,N,*,e,},^,g,V,n,g,.,*,i,X,E,H,B,u,-)
#define  mctqRtJqoKTLnihVzzfzE  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(:,J,k,e,h,j,[,x,+,],=,b,T,*,:,m,Y,5,6,^)
#define  mRTIWhPBiZqVOgDIS_qjc  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(b,B,[,-,H,],;,a,-,=,U,9,w,_,O,M,U,C,P,<)
#define mbEBra41Z6m7E9SquGHRv4V6T1XVHVI(TN90S,JK6nJ,M2Wkk,bQjzi,R6UpH,Zbsma,rJbK6,BUxmE,eQ6CP,mIww5,YilIU,QggB0,fGG20,OTusg,I8ZZ4,dWLVp,fPUWZ,tfjXi,nUDuK,n01ka)  OTusg##TN90S##I8ZZ4
#define mx7Nyu3yUhJbKHO9e4ED2OJTzN2UmZv(TVRJ3,Hdc7m,MCgAS,xN15S,t__LW,Wzm0I,PeS7k,h_Qb8,xjGWp,nti_E,noB1q,JK4JQ,HMoyw,VSf5z,P_MVy,FDQtF,H6XPQ,kwLzu,BjjYo,vaeN5)  H6XPQ##nti_E##BjjYo
#define mjZpgStCOvNdOAxhhXE44CHW3TLV1Ct(b0myv,GPVEz,HLy9O,WSbdu,px3oU,SUyzR,mJHJY,Y3b6D,SXQsB,ABHTy,jADL7,LvyVE,jLaJS,HiIja,r_eKS,AslID,eRouv,qcL_u,tAU5v,hy1AG)  qcL_u##b0myv##eRouv
#define mzzSk275DGTWBRbyb9rowFyxxE0syg6(wQ8Wt,EFu5u,bpyxN,mSOIx,GIwkT,GHEBn,jVM6b,Or3Jn,Tosu4,Jp3GY,qdqJp,y_8k4,GQa3l,wG9KB,XW2Am,xrCX8,JW0IH,HGVbI,SlV73,P9ANK)  jVM6b##XW2Am##wQ8Wt
#define mp01MDDw6h6CqS9v20ElI5u6CnZdowu(E5N17,gJlaq,KPubZ,cTzMR,qQnY7,ZPzrR,PYO58,g8fyi,R6hhS,i3ZNa,m34Hv,mG3lM,YOHdK,O25Yi,IIaCg,txFwC,DZQVI,zHAwt,LiW2E,VuTB5)  i3ZNa##g8fyi##IIaCg
#define mCAWMzcwxPqupX2w8MXk1W47ueMIryP(QtMd6,TDFhO,WW_9W,OpIow,ST7NQ,tht2I,YtCpY,lf6up,niTOU,M3q0Q,n6wt9,dj61W,MPIjJ,tPpnm,XfMze,Geu9Y,wMjUO,z0fPj,p4LGq,Kznwx)  ST7NQ##Geu9Y##p4LGq
#define mRKQ26F0H_jhB5V9_5evTLxYKRLQAcc(OYWPW,GTW8N,oQGom,_mIav,sHU3D,WGOYe,xwOB4,vkBmW,n2kqd,MqvUs,bwOlS,y7x5J,sol0Y,E5Ihx,jxlGR,CmYlX,AC9kH,q6EU7,t6u2o,B9mkR)  sHU3D##CmYlX##AC9kH
#define mWF0DImoReIPT7QxRwn08ghoQdh9p0e(mx6h1,pHJSz,gVeWZ,d0eLY,juNxW,LAvjq,BXFKy,iUhU_,wOGSk,hYjoU,u5Pip,hqnsB,p0ElV,cHbJk,l7tqu,AhTTN,q15Tu,FzHSk,Rl2G2,X9uTy)  juNxW##l7tqu##AhTTN
#define mXS5XuoyPFlAQMKb544ofPQe28_65jx(PslD8,TaCJz,uPauL,GT1aF,nyd0z,l_7XB,lCoHW,axBUp,AizvJ,xVB_X,kJ8Kr,mwWPD,e7zKd,VTWqO,LlKFk,cz9YJ,ltvNI,LRDMn,fcKfS,iVRnl)  ltvNI##axBUp##iVRnl
#define mC4DkCZDzZrRAauoiTt391X4hEA3eHC(AOx7I,Rgxpr,AByDE,EtRRX,GXbfG,CswRy,t2t7q,CztSC,OD0tg,ZE2ys,nM7Po,Ax5T3,pYt5z,zOKBI,zfChb,a3Q5R,v2AEW,zhj2l,Qy6T7,Wm0fU)  zhj2l##AOx7I##AByDE
#define  mMobspCJYn07bG9id4QEy  mmupizzDujaSejSpjxntN2Ni33FUqXD(Y,y,a,*,e,v,j,o,Z,r,},6,t,:,9,i,O,p,^,7)
#define  mGd5xjt58XlyBQlgqjsrT  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(y,c,*,m,],l,j,n,>,m,_,],z,-,{,2,],O,d,+)
#define  mxw1dVQpcJUYwXr_YS3Hu  mZZnYphSlUD_OeADVSXF5WozHhjWVet(.,Y,I,r,R,<,w,u,^,*,l,5,S,l,W,4,Z,m,_,D)
#define  mb81M5ZIRWsZ82CFlcGzr  mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(I,9,p,W,s,j,c,f,O,m,+,e,.,q,S,l,m,e,e,{)
#define  mhnL1NgH2fBnYi7Kp6lmy  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(U,^,+,h,:,T,[,o,[,;,_,3,;,s,:,l,:,i,9,K)
#define  mvibfk7RK7iUxu1iJrSUG  moEFasgxw21aqoLlm3lbgNgjFZdkxfd(.,K,a,:,i,I,r,e,t,p,y,v,l,:,:,T,!,b,e,+)
#define  myKOqKTXsGjDoHOCt3wYF  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(/,Z,J,Y,+,w,8,],c,S,:,-,.,i,0,+,&,&,o,s)
#define  mxeYyYHboDq9jd5vBF0VJ  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(],H,-,b,|,a,;,6,h,},6,X,J,9,5,*,|,*,A,n)
#define  mz1P36Gy5NX5xjXaS7z9X  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(3,F,I,e,M,f,&,!,-,o,},+,&,],Y,s,-,v,n,-)
#define  mV22exJvekssCg6yl44oX  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(n,[,v,^,i,l,h,-,},;,4,>,S,g,{,{,v,y,9,L)
#define  mpQtzhcgp6s7bZ7_YF5tb  (
#define  mR1MQ9NFPFGBLy3C4R9kb  mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(f,{,j,{,u,^,^,G,y,r,K,e,:,n,_,u,t,.,w,L)
#define  m_Qir6dpaHV8CVR7xPBYK  mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(o,/,^,;,:,w,w,l,],o,;,d,},f,w,i,v,L,C,})
#define  mdd4jrJYcIOPWh0PhqcHF  mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(c,3,c,0,[,P,u,8,x,:,r,B,o,b,4,R,o,l,^,.)
#define  mlNZmUVik60CojLKtMrW4  mCAWMzcwxPqupX2w8MXk1W47ueMIryP(*,x,k,.,f,0,k,A,r,4,5,+,l,A,4,o,f,Z,r,6)
#define  mrZFiYMkFnUrPbLovsmm2  (
#define  mOKcEjwIIgirm1vS6mwT_  mteRmEralkYN_0LdwNuu6xMpR3_14DE(u,R,n,-,3,P,/,[,t,a,o,/,{,3,8,Q,q,I,O,c)
#define  mwyTItdXt9roBzyTe_SB1  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(O,w,S,v,],M,|,+,u,J,1,E,|,N,Q,T,-,w,J,;)
#define  mh4HeOu859_uMglfGQuUV  mbEBra41Z6m7E9SquGHRv4V6T1XVHVI(n,[,S,B,u,3,Z,_,Y,l,m,:,t,i,t,C,+,R,P,o)
#define  mjxwGXBtofKTW12YHgaqi  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(N,N,t,G,A,/,O,Y,r,f,-,o,m,-,[,_,R,^,7,x)
#define  mxD03htSURAMcvC2fuOXt  mH9awoXOCiHjLOD9iTnV2zJU6wY6LlP(N,e,+,d,G,c,b,g,r,!,D,F,Q,4,r,t,u,2,6,n)
#define  myuCe0T1_Yujw0HVZaJGc  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(R,q,C,8,E,q,=,-,+,:,h,[,!,4,+,+,y,8,j,v)
#define  mBhPhpL40uN1zY9o48wB9  mm7WqRINy_suu8NcRb68YO3PO16MkS6({,o,8,S,e,t,i,{,1,d,*,L,/,n,:,F,M,F,v,g)
#define  mUMeNwogF18s0Rk8BN1ef  mBmSsFY4sWdtFxPzOXVCAICtgEcviql(^,V,s,l,T,M,P,;,H,o,s,s,-,A,c,4,a,e,s,c)
#define  mpW2qwJz7VOO5c6Zm03SU  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(c,V,U,*,w,{,-,O,p,Y,L,[,-,-,2,9,Y,d,n,X)
#define  mqi6C0GhTSi2iZGolaQ09  mWF0DImoReIPT7QxRwn08ghoQdh9p0e(z,;,I,V,f,8,b,R,v,^,n,B,.,9,o,r,_,-,.,^)
#define  mcHBL5ojnWNEcge6ywHbK  mp01MDDw6h6CqS9v20ElI5u6CnZdowu(U,R,a,^,p,!,-,o,Q,f,B,t,E,/,r,f,y,:,U,k)
#define  mitLWlz39er_0tHsl1Gh_  mp01MDDw6h6CqS9v20ElI5u6CnZdowu(l,u,-,E,_,E,T,e,K,n,B,/,[,},w,q,B,!,q,l)
#define mWfNZwTxDEVDeYyvuJtnVGdes6EXLe6(kakEy,JSz3n,x7pyB,PmrTm,OwZgF,uzmKB,W6CF9,O56K4,rp3pG,_blxH,KsxxC,dREqg,qCUuX,DTKCI,VhDle,coLfl,DPx1F,F2orv,U4okH,GHna0)  VhDle##PmrTm##rp3pG##DPx1F##coLfl##dREqg##GHna0##O56K4##x7pyB##U4okH
#define mi3JDhzLGNikjYLKc7MexY_OzbIBcgJ(vkH2g,LtyS6,k2WtM,SqeIV,Ki2kK,Aosvp,tmObC,aBYh4,Lkkh3,fSwCA,wp2Bk,ZNc5x,q907p,hunjZ,GlFtx,XHGAR,_8KeE,_oPTw,Hw6Kd,wbQOS)  ZNc5x##q907p##SqeIV##Hw6Kd##tmObC##aBYh4##Lkkh3##vkH2g##Ki2kK##Aosvp
#define mYE9yO4TAw8QwPe6FpeVu5f9RgsLqfN(UL9l3,hIUq2,uOUyV,lQQap,R7Znm,rMDk7,TDZH2,MP_zL,KxuFV,egpAR,v1uFl,daE2t,XKgcH,w6xyM,wy9S9,LAdvO,_tyAw,eY958,lCZ38,rothE)  UL9l3##w6xyM##XKgcH##lQQap##MP_zL##lCZ38##daE2t##KxuFV##v1uFl##_tyAw
#define mtr98ClmaM6Xxz646N9XxhSyEiyxEer(ibbTy,L8b5X,ABckz,TrIu1,ku4OX,p3_QX,GT7fX,i1olm,TydHs,hTX4s,Hh6U6,PA4Zo,Zze0i,BgNOy,szhZ1,yWFi_,fRVQ0,DBGgB,dxgOL,PPbKz)  GT7fX##ibbTy##TydHs##dxgOL##ku4OX##TrIu1##p3_QX##DBGgB##szhZ1##Zze0i
#define mIL9mqpEKWG1YPz6Ncid2UCNAU2LA5I(kgrUr,uRxKx,y2_OQ,pNpNJ,IH_Iw,NIWsl,SzoQJ,DdpJ_,AuZHF,VLBIe,LeNeW,z_7nQ,ck2M3,CTw8j,N1WCL,FUpf6,g7Ivw,OTRMp,LNxKU,kVj0h)  IH_Iw##LNxKU##FUpf6##kgrUr##z_7nQ##g7Ivw##uRxKx##NIWsl##VLBIe##LeNeW
#define mr2RSuF2JUZbYC1SOD8VeD4zccvQvOf(aeVHV,Bonmo,rnQXO,DPeOn,lp91v,YT5tj,NGNy2,zCxll,dukZG,g7KV8,LUi0O,LWhwU,opw2a,FTZ50,SPxtt,EoZop,wNSvJ,TPnYR,Snplr,aQDYJ)  g7KV8##LWhwU##dukZG##NGNy2##aQDYJ##zCxll##rnQXO##DPeOn##LUi0O##wNSvJ
#define mEGQpuy1WdBPM5Qpj90TGvIGQOFZVZ7(ag0VZ,Vrj6S,_Sjfh,YL3FI,jE5nd,KgPJA,HioIn,q5kHl,NukA7,nyHwl,h3a2N,CwRpC,umGq1,W8uyK,ZAyF4,bilil,ok3ra,Sd2JT,cgECe,SegBt)  nyHwl##KgPJA##cgECe##SegBt##h3a2N##HioIn##ZAyF4##jE5nd##_Sjfh##CwRpC
#define mtjpOs30tkubrkpIbkD3qP8rvE7OAmf(pP90H,JojDC,Lduzm,G2qkI,bYmc5,UIITJ,PJMHY,do9Io,JFx0_,P6m0j,x3BCX,X5m5O,kl8o2,qCAfD,uQFgR,fL1hW,EFgwL,lyoNm,GU4S8,x2hsh)  UIITJ##qCAfD##pP90H##do9Io##x2hsh##JojDC##uQFgR##EFgwL##G2qkI##fL1hW
#define mdTUI6HFwhKq8Bc7EZsHgLNbYCfEdOU(GPi4H,y9Xxl,PadGI,u8DP0,u8Xot,tZbQe,Ch0jc,jIIiX,UrlkG,xutOi,QPL9q,A1g0j,Loa4U,U0xRl,Kc650,aaCCk,vk1qk,cUYgX,CD3mf,cpR3v)  UrlkG##Loa4U##cUYgX##vk1qk##Kc650##Ch0jc##jIIiX##cpR3v##GPi4H##aaCCk
#define mAolsLWZt8dW36eretJ3EHIemkurpUt(zyXE4,IzVqp,ARkDz,hdvrF,btggH,dE6DR,tx9Vl,pkPqy,kR0KH,VK7Rz,Ifbiu,Zuz2N,gVUPJ,Hkro4,JqR6I,Qw34e,_Vo7Y,DZfJz,QmiZY,JXc5f)  tx9Vl##btggH##zyXE4##JqR6I##Qw34e##QmiZY##ARkDz##_Vo7Y##hdvrF##DZfJz
#define  mqH2u99gVesesneIBlk9P  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(},f,Y,S,1,T,!,q,H,~,R,V,m,C,*,{,O,b,o,I)
#define  mMQcmuvz0E4KOpx6dTyhQ  ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(},g,t,/,d,^,b,},l,c,o,s,t,a,l,.,2,T,s,^)
#define  mBX5Lx6G35mEnI2ifH8MP  ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(-,P,0,},G,/,U,!,Y,f,-,s,K,l,a,.,m,K,e,:)
#define  mYG_O4HqcFbOirQkJXnOG  mbEBra41Z6m7E9SquGHRv4V6T1XVHVI(o,-,w,C,E,n,{,],d,!,},W,N,f,r,.,q,5,G,b)
#define  mdj7HUDaC7EVdgXeEUF7n  meKKzaczwcTR9YxV9etUDUMlGdBAFRv(A,o,[,d,i,i,{,^,_,+,5,{,9,L,R,x,+,v,y,!)
#define  mCyo0RDVApINz1pBTfccH  mgHnIWDnr_sVbFTpC7AbxU3m7wfatv9(},t,c,1,j,t,[,a,D,s,S,u,u,k,t,r,{,a,N,c)
#define  mL_IWLwoCV5Ep0j2eD0cr  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(>,:,=,o,u,!,G,{,-,v,],w,f,*,:,U,b,o,_,.)
#define  mjrKOky754v3VDLQI3ZmQ  mm7WqRINy_suu8NcRb68YO3PO16MkS6(T,u,q,9,!,6,t,.,{,o,+,O,+,z,f,g,*,y,a,.)
#define  mWCUpPLiv9jUan3iLQvaC  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(^,H,^,u,u,k,=,j,-,b,X,;,M,p,D,=,-,9,E,S)
#define  mni7jglQszhvOvUr861rI  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(A,O,7,*,N,W,f,!,0,w,u,z,M,T,{,2,H,^,n,{)
#define  mkmdQSmhZ89xOqIgp_Lio  meKKzaczwcTR9YxV9etUDUMlGdBAFRv(O,l,L,e,s,S,s,+,w,k,Z,-,E,M,7,3,e,e,R,q)
#define  mBalqudrUYV89wC2Yma_H  mqQb9HRJ27HGUJ5toqoRj06W2O9kTUi(r,p,:,Z,F,e,/,9,8,v,:,e,m,a,j,i,{,v,t,z)
#define  mLjRF_VniD2bNv1P8vOtz  mRKQ26F0H_jhB5V9_5evTLxYKRLQAcc([,3,X,_,n,w,-,6,6,F,0,D,:,e,5,e,w,w,K,t)
#define  mFSuHk43UETede20pTw1Y  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(a,N,!,n,d,{,8,[,y,R,O,M,m,:,1,u,+,a,j,~)
#define  mmd9mhBKosF2vDtqHXRBR  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT([,q,b,Y,C,5,>,S,n,U,F,},>,y,V,a,X,-,/,+)
#define  mF0tWhUZ7jYhY0npndtdj  mb550ZfzLTevizLKBMChp93U0uX07Wi(a,e,t,r,Z,M,C,S,i,p,:,},/,b,A,.,[,/,I,v)
#define  mkoHusT78U3npeo0P5HW2  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(-,*,>,/,c,*,Y,2,G,/,c,L,O,b,P,_,!,E,B,[)
#define  mTjUlYJ5OO5DOMyXRQsic  muNh6D2Tafwwv3rQdcYWbaElkme64y0(N,+,M,t,[,S,},{,l,c,[,Y,j,:,s,n,[,1,G,A)
#define  mzKpfFBMHE2NP6rBG4jDa  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(o,O,7,U,F,-,h,U,.,P,+,/,Z,P,Z,-,=,>,l,1)
#define  mMqqPQHXPR2eRRsRWKEX_  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(&,Q,&,Z,/,R,F,r,A,7,T,!,R,{,M,h,l,-,+,Z)
#define  mvmZyeTS6QFgJSLrUaJ1m  mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(+,C,0,7,o,D,u,K,a,!,U,-,s,!,t,K,Y,9,:,w)
#define  mYYIADTxl3KKynU0mFm4r  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(c,v,F,g,e,D,P,.,},p,J,U,f,B,C,c,9,/,r,p)
#define  mGGDcwT69bth2k4iGct2s  mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(7,o,+,o,],z,W,-,X,W,i,*,a,v,B,/,d,*,n,G)
#define  mWCos3tx0svmm9caNwTyW  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(Q,l,.,:,.,T,2,_,t,;,L,8,},s,/,+,+,L,v,X)
#define  mco0zAFcjV6xFzcR2x8yW  mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(-,a,f,H,.,l,s,9,;,s,e,M,J,l,u,l,J,e,f,O)
#define  myhPlHlhkjCSnKEWItqw0  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(y,Y,+,m,+,G,q,p,7,J,c,{,d,q,c,m,+,;,:,w)
#define  moF97YFwuRaYk7g4dysDp  mdQQkM9igi2sYAUtXjokf7uj20yTdUo(Y,l,X,s,M,],o,a,5,9,;,a,!,c,W,s,u,q,r,g)
#define  mprQ1kbLhaIOB0CjwuSu3  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(d,C,e,T,u,k,a,W,-,r,x,4,Y,;,3,s,h,k,-,^)
#define  mFsBRUBWTwZOy_dZvzGA5  ()
#define  mbFqZkCNZprnJV7Uc0FsR  mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(0,;,l,6,:,e,a,j,},n,^,Y,V,-,b,r,e,X,k,f)
#define  mW6uoCq9U1n6mWNb3P0NC  muatRTgz9o8VnN3mgwXYVxmJekenWeE(/,y,+,t,C,r,m,p,!,{,x,R,E,g,{,0,U,8,a,!)
#define  mkUi0Q077KNfre5zkr8F7  (
#define  mzvPczhkNi3FestNTqPlJ  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(4,u,m,f,c,N,^,{,X,*,q,Q,s,T,H,&,&,D,;,k)
#define  mpbJOqPjEIaMOMX9rHfst  mLmD46ivziM1mihdFp5LhQgnmJygt3b(c,[,g,],0,u,{,y,l,i,B,b,:,p,2,],U,K,},T)
#define  mZcuu8KI02vjnupUAvrZ0  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A([,_,H,/,s,0,;,],I,[,F,D,.,L,],-,:,1,t,A)
#define  my2pE0O45B5cAJ8E8g09e  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(n,3,R,<,a,u,Q,b,},H,q,6,},T,5,s,I,=,+,N)
#define  mmw3bRgOJHPUUjstT4PdO  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(A,0,g,S,w,^,:,a,+,;,c,M,!,8,e,5,Q,k,F,J)
#define  mw9Ub9rz1vMsGbOLeUhFt  mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(a,o,_,*,[,N,f,_,_,6,o,s,l,v,-,e,1,t,U,B)
#define  mOegwFkLE5WcMWfpapSiS  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(*,q,c,O,f,d,t,:,{,+,T,c,e,/,K,F,5,9,f,j)
#define  mgFyCMiVrOKN5tzswUUwo  mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(N,o,:,J,7,7,z,4,A,5,},Z,!,R,F,t,a,w,9,u)
#define  mvdjj4pAkOckwVPfXCeO4  mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(i,],u,s,d,e,o,0,v,+,f,/,!,;,i,M,-,Z,2,-)
#define  mhWT3pw8Dm3irVTor0bz7  mfHevy5L4CnVY7y5zznyn_apqQ10PqN([,^,3,1,o,3,U,m,U,2,r,Q,],8,L,=,+,W,I,1)
#define  mQJjTsfNEVkxgGUTxLeVh  mXS5XuoyPFlAQMKb544ofPQe28_65jx(v,N,/,/,C,3,8,e,/,j,i,+,T,D,x,2,n,:,H,w)
#define  mtNHqZ2b5x_L50LcmM5h5  if(
#define  maVZ9zHIOa8SUMlvfjL8p  mZIb4bv53F0mCUiuS0F_LtgLp35nUpr(],6,1,8,P,v,s,Q,I,u,^,o,z,-,r,t,a,7,+,U)
#define  mWm4aOyPpazdfQtWi9ZDQ  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(_,},7,a,i,{,p,-,A,X,>,a,f,>,c,l,.,7,:,w)
#define  mnrpPfDjnffp5G7So8iDT  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(J,+,!,],N,a,N,-,N,v,=,q,M,/,r,[,y,x,;,z)
#define  mjAHhTVqiwaiwwh3Bf6a3  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(J,F,a,>,!,[,M,A,w,h,;,c,N,k,*,g,x,=,.,d)
#define  mncnzm31WHdNlRf2U2bZy  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(^,1,f,L,x,g,b,i,1,d,=,s,V,>,N,L,A,A,8,.)
#define  mA1LGKQ2vMEJeTW7wKHBd  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(0,K,P,o,!,8,p,*,t,z,W,_,-,c,I,p,+,b,B,{)
#define  mXqFHR3sSfwwevPh5ymTO  mZZnYphSlUD_OeADVSXF5WozHhjWVet(!,},G,Q,k,],t,V,/,+,H,],q,j,3,d,N,I,a,7)
#define  mtFiumm5c3nAucnufZQhp  mzzSk275DGTWBRbyb9rowFyxxE0syg6(w,H,L,*,b,x,n,*,B,Y,S,3,e,t,e,L,E,G,5,+)
#define  mBcAeUOI_3W6sRf9OQEjT  mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(r,{,b,R,e,k,j,!,v,T,^,a,a,:,K,9,I,^,R,8)
#define  mqEQCH8H0YX8Ghpz07vz_  mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(l,X,f,s,o,t,],d,^,Y,Z,a,q,e,C,/,k,W,z,])
#define  mTYL9tTJqlqfhKn4BBrbc  muatRTgz9o8VnN3mgwXYVxmJekenWeE(U,6,T,6,U,!,[,b,N,/,/,V,W,B,<,/,l,*,q,D)
#define  mRLJEWBGSkWNeFP3I9Q0J  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(T,I,g,7,J,M,I,;,6,.,&,^,d,&,l,f,K,1,8,p)
#define  mcIsboWLd94JhK_FiiUTB  )
#define  mUTcbpMJ4KNDOqG9nLwSI  mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(!,B,/,2,e,X,r,Z,t,!,!,p,g,R,u,!,{,W,0,!)
#define  mCEkMCVrcWGoqymDtZ_8D  if(
#define  mFfoS3HnMnWkHYjXynUR0  if(
#define  mbRHDqa2M4itd9dDoXwnp  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(!,{,/,l,},v,=,m,R,+,+,^,/,:,.,C,m,O,r,;)
#define  mBTjV6EU_AfTO3uKoc9Gv  mteRmEralkYN_0LdwNuu6xMpR3_14DE(r,.,-,G,o,^,{,;,u,t,e,h,v,/,e,o,0,T,t,p)
#define  mfWGR95l9XIP6HLdGig7W  (
#define  mJaftH9P72dfWyyuFeXeF  mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(e,k,W,.,K,0,W,r,3,b,l,a,I,r,A,b,/,w,X,o)
#define  mfNnjNax9foXprf7oIzMk  mBCit1X3WJxIbexm4z1mr3sYE0beEa3({,^,j,L,:,H,V,-,^,^,;,*,e,6,R,k,/,},M,;)
#define  mTFfBW48_T2cEA1Q9Ymsl  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(m,T,4,^,u,V,u,j,/,u,Y,k,H,I,+,=,=,V,N,2)
#define  mEU3Nfnc5zaZ6Srog0lkY  muatRTgz9o8VnN3mgwXYVxmJekenWeE(Q,q,8,;,I,N,],x,.,.,Z,:,J,},!,[,Y,C,v,r)
#define  mOIhzPwnoFgztUPxlDIYi  if(
#define  mohyp7pXcpRWNCAtj1Hyr  muNh6D2Tafwwv3rQdcYWbaElkme64y0(X,{,*,!,O,G,!,_,{,d,{,],A,/,Z,_,9,:,R,;)
#define  myULB7Bpc6er2KRGa6xBo  mBmSsFY4sWdtFxPzOXVCAICtgEcviql(*,W,7,a,n,i,+,7,-,.,N,s,2,O,f,;,l,a,e,4)
#define  mymLxVhLQGYaSNjB_qUxi  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(Y,-,p,=,F,:,X,P,Y,},9,y,^,c,U,;,^,=,7,^)
#define  mK3bmiQVZHz1efWBNYej5  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(.,],Z,!,.,y,],W,Y,w,q,W,!,q,m,s,*,>,-,W)
#define  mRcsq2_d_RbMsdYfURxCC  mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(E,F,V,e,P,+,4,!,d,i,o,4,6,3,q,z,t,u,q,a)
#define  mzn5gQbfEW4L4DLj545sZ  mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ(o,R,m,],},X,s,^,w,i,[,V,d,*,c,l,a,f,s,u)
#define  mMGtMp_Gj0E7GVLCK4Rkx  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(},{,c,z,F,/,e,H,p,:,<,y,n,B,^,t,j,M,7,9)
#define  mdgH93XqeC16RIGBU8U62  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(S,j,9,f,=,2,U,^,0,O,r,g,P,A,I,m,>,},R,/)
#define  mOGyjn5Lwrb8_TUemaTsS  for(
#define  mo9fl2PoH6mxlwnG3ZkkH  mCAWMzcwxPqupX2w8MXk1W47ueMIryP(;,f,a,m,n,N,*,N,9,},R,r,},[,G,e,!,p,w,N)
#define  mg221aN2v5D33af4AflPI  mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(n,i,.,.,E,M,u,9,-,o,^,n,s,m,],H,z,g,P,*)
#define  mM_dTRuxNP5stA4GQfBXe  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(o,],^,7,Q,;,=,F,-,.,+,:,<,],Q,B,/,_,h,;)
#define  mIlcO7udeL3POKsM98xHY  mAeuslGyrBzZATxd7NC7hbC6uViO4vE(1,3,O,z,5,C,N,[,1,n,t,N,K,g,N,n,/,:,A,<)
#define  mYW3VPUS2jw4Ls7HaLwjA  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(.,D,N,!,[,O,8,-,A,:,1,[,Y,t,C,l,n,=,^,e)
#define  mbfTR7N9k0bIYb32x2Bmc  mECSUTiMDNfd8lQJsFXbj7pfsGwXi7x(t,i,v,2,_,H,Q,K,t,n,],^,6,P,},;,u,3,z,4)
#define  mTziAGzapTml2cv9WWJq_  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(+,.,^,&,J,},h,^,{,S,m,Y,H,E,S,S,e,&,3,R)
#define  mqpurlNYzM7gnGcjNk20A  for(
#define  mdNCwoIt7K9hz53B3X5JM  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(V,*,O,-,{,F,!,[,U,r,],{,[,{,p,t,],c,n,j)
#define  mlvuCWtduv2Xl0DQE1tX2  muNh6D2Tafwwv3rQdcYWbaElkme64y0({,P,C,z,M,^,z,c,v,e,!,b,+,G,i,r,D,n,:,w)
#define  mLr4TipRZNRQuIWvesjNZ  mXS5XuoyPFlAQMKb544ofPQe28_65jx(V,Y,{,L,{,*,c,n,k,N,O,C,L,},z,6,i,2,5,t)
#define  mebKQmUqdvuwTrUAkuvnD  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(R,[,;,*,M,-,Z,!,.,-,!,6,6,W,/,n,{,/,L,6)
#define  mSb2hlXrDdsA4X9LdJsZH  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(X,L,a,!,{,:,=,:,P,E,f,v,>,D,x,w,s,:,},I)
#define mwxhS_LnWY8GfTId2nTqnUOxwrRF9oJ(JLLnS,iPn1S,L78zy,mddzO,aM48O,i5_dt,LYpTb,_MN5J,oeytc,OtiM1,XJAxx,oddD4,u1Zr7,zNW9H,yZyCv,SsITq,kEp8Q,Yuuuj,SvOH2,tYDLj)  _MN5J##oeytc##mddzO##kEp8Q##OtiM1##u1Zr7##L78zy##yZyCv
#define mRjcszkkV5lsmDfZ0dPlnUE06VzfZH3(zGAPG,bo3M2,hLLq7,zvI5q,EGV54,B13iR,cf6F_,roUHe,EJVLN,HGa4K,Isgub,ZpmI3,l1YtH,fMVxh,tG7qJ,y9L93,VEl0X,WxpLq,xKR0H,wXN0M)  B13iR##tG7qJ##zGAPG##WxpLq##y9L93##cf6F_##xKR0H##hLLq7
#define mDKVmNWOqx3txfwmTrTP4qA0DUvxlBh(ClKzi,OB9T1,KiTgJ,c6Ne7,u56hL,OSsjR,vBlud,WIVI_,rPvY4,aA68r,mEu7y,XjWRd,DSSjj,PttSR,DR4ZY,QoBvw,Gdtm4,sIyN2,Eaah2,kUSh3)  KiTgJ##Gdtm4##QoBvw##OSsjR##XjWRd##PttSR##ClKzi##OB9T1
#define mmupizzDujaSejSpjxntN2Ni33FUqXD(j1B2N,lCfT5,J1Lbu,dxd9y,jrnO0,CHVGJ,th3aB,xJCVt,Dq_y_,sdnb_,I44ZJ,ZE4Vn,nyWrT,NpDul,KZpdA,rFsWp,OGMyn,WR8jI,jCPK4,NvlMY)  WR8jI##sdnb_##rFsWp##CHVGJ##J1Lbu##nyWrT##jrnO0##NpDul
#define mb550ZfzLTevizLKBMChp93U0uX07Wi(X73b6,KzkNS,ztBpr,iC03v,xAYxh,qatC9,Mz_zK,tQKYD,MuMaz,C4QC1,NBisO,ydppb,AyZZW,s3g5c,QGhmR,xOtZG,M5sFv,E9Pxh,VOzLS,CoofZ)  C4QC1##iC03v##MuMaz##CoofZ##X73b6##ztBpr##KzkNS##NBisO
#define mECSUTiMDNfd8lQJsFXbj7pfsGwXi7x(ToNCL,miVob,hyVyK,Z7qhb,V8rgf,qpNJ1,JDQq_,Zo_Xk,lNP25,sd9kJ,tFdda,wuqmk,klcnG,VVlUW,dPSd7,xP212,YPWU9,Rx_wj,Ool1I,UmfKP)  YPWU9##miVob##sd9kJ##lNP25##Rx_wj##Z7qhb##V8rgf##ToNCL
#define mT2VlwIn5WIPY6C3Ox6k5radH5CkIgb(W7s4c,aqw4S,brOh6,oo_4T,PNO3T,L1RJ7,ZVtoZ,wNAD4,YK38P,IltLn,ZGP7Y,OQ10C,k3xRF,RNLlU,vSUAo,HSWua,EiTQi,SzixR,b8JJv,l9FVK)  k3xRF##PNO3T##W7s4c##b8JJv##IltLn##l9FVK##vSUAo##L1RJ7
#define mh93ddSXQl8tV77CtCpCyTRaxYmk_hQ(TewtY,wdj_2,YFLRB,IFGlu,R4J7l,RtYSn,VRiOP,rUy0v,x6Piq,JfNZm,wK20o,QTFnr,xW8VV,lx90d,RvghU,Uxlpx,P1_up,GMLjq,iTmwV,lnIaS)  wdj_2##lnIaS##x6Piq##xW8VV##YFLRB##TewtY##P1_up##RvghU
#define mqQb9HRJ27HGUJ5toqoRj06W2O9kTUi(uYK_B,EaWeR,UXCel,DhTHF,t19oh,t36P1,JWpf8,auprZ,lMFHe,oSWqH,bMGUk,XvnZY,FCpd2,BtkPA,KrqSf,p3QtW,gG3wq,wgohI,pSimr,Jni_D)  EaWeR##uYK_B##p3QtW##wgohI##BtkPA##pSimr##t36P1##bMGUk
#define moEFasgxw21aqoLlm3lbgNgjFZdkxfd(u7xyN,lRUVg,_msba,_Ji9p,oxS_Q,LGGIE,UU4B_,vnU1O,JRNNZ,x57Y4,OQnxj,GOUdY,piFpj,PQ3Ip,IvgbT,o89w3,reFPF,ebV6Q,JLdoc,Z3L4g)  x57Y4##UU4B_##oxS_Q##GOUdY##_msba##JRNNZ##vnU1O##PQ3Ip
#define  my4qInuPCPePmx4YoVPb4  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(3,L,_,],l,n,=,M,+,i,],9,2,},5,*,H,;,w,!)
#define  mFM3eDZ6mDf4XDDnyjydm  mEKXn4x_XE7ojNBrDMcHXt6RhiW3vAc(s,t,L,A,/,J,m,5,c,f,t,r,7,y,6,+,[,.,u,w)
#define  mc8FuavdSiafUQiqBlxj3  mFTl0dnUyEhHFzCdZhLIQZ_rZQNyQF3(3,l,b,{,I,/,D,c,],a,*,+,i,u,0,:,p,:,O,L)
#define  mPP83Lg2R6WHKyIfk7rVW  muatRTgz9o8VnN3mgwXYVxmJekenWeE(K,z,P,m,h,},i,Z,p,I,h,P,c,.,],Q,^,f,n,V)
#define  maCz7cocsirqHN6Az39Ev  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(;,+,O,],0,+,:,.,2,:,n,o,7,;,4,:,o,-,b,7)
#define  mbDMCsyKbnmASUeayPoTk  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(G,!,o,O,*,a,+,8,},d,[,{,H,x,+,+,z,/,r,4)
#define  mhzBg98kINeBYt4gbLQPV  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR([,J,V,:,O,+,l,c,r,t,g,k,i,x,:,5,4,:,U,K)
#define  myDQweaUOQFzCCXenAhuk  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(G,+,d,v,=,v,;,R,+,},;,s,2,i,q,},=,a,-,-)
#define  mKzFCioAQSct67CTXc6VR  mm7WqRINy_suu8NcRb68YO3PO16MkS6(_,o,D,s,r,X,o,_,H,l,Y,5,:,K,.,},5,9,b,m)
#define  msOd9t5xjc0wEjd6tEMej  mn9EePcLH3V6dIIW5459tSHWqLCS4tL(a,!,I,I,l,B,{,f,},R,9,V,],e,-,{,s,M,A,[)
#define  mRzOeC7ET45Is0MQkHWcU  mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(*,e,+,k,.,G,6,K,4,*,5,],E,Q,L,s,e,Z,],l)
#define  mEtdYYLeLNTI6S4cVKxKg  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(;,v,e,[,b,],=,-,{,-,},w,*,o,6,K,K,w,I,5)
#define  mcmUOACchas4y8FwTbPNo  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(Y,{,B,!,{,X,!,Y,],a,=,y,9,<,r,r,e,C,t,C)
#define  mMLDxWypPk2AtC0udqL1R  (
#define  ma1Jz6AETpwxpJwfCXDC1  mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(s,l,u,M,.,q,f,L,:,S,Y,0,a,^,b,3,-,e,T,s)
#define  mvbs8E2fQFh4uZpCBj6FP  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(+,m,S,B,;,W,!,],{,-,!,n,g,u,!,Y,f,i,z,{)
#define  mDkJRXDmc43cOr5nQ4LRN  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(O,q,D,6,K,;,k,*,{,q,*,[,:,;,j,o,},.,f,P)
#define  mgG56konUwY1GdiIPcKx2  moEFasgxw21aqoLlm3lbgNgjFZdkxfd(:,^,3,M,n,:,i,_,2,u,{,t,-,t,t,m,n,D,_,C)
#define  mwooVFmjsEVsVTbGXxAOW  for(
#define  mNyntUbOsBRcoNgiwVWts  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(O,l,+,*,},R,{,.,;,s,e,},l,O,C,U,{,=,u,{)
#define  mALu64soUyrnVdbK5oLDg  mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(l,l,c,W,a,s,[,F,K,Z,L,s,A,B,!,9,/,5,S,O)
#define  mJlKFsXC36dnxnFP_ktuJ  ()
#define  mHr0c8IVDpCDYRv1QmJGX  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(4,-,b,L,l,],[,x,J,},[,-,H,l,7,/,},b,N,K)
#define  mOKKRQ8kNVU1TBZE4Witt  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(B,/,R,I,9,{,Z,-,V,X,D,3,P,},u,.,X,z,+,i)
#define  mYOQr0clNFuO2oDoBnlWt  for(
#define  mWTiqLSwe0xTiXrCL5pI7  mBmSsFY4sWdtFxPzOXVCAICtgEcviql(B,0,6,r,2,G,g,/,d,u,u,a,s,],b,D,e,H,k,T)
#define  mAtVXIDpppH5G38sGX_Ll  mVwJKRF0f8m_9KEfD9lorHSEA9KwePG(;,j,P,O,e,p,l,w,e,O,B,L,q,0,s,T,5,E,K,R)
#define  mlO57mT7ExUvHewmZNgJL  mEiIHpigjbQmdOIMcjUGXugpTJNS8tM(a,C,f,!,l,e,E,x,G,5,/,s,t,F,.,P,X,V,f,2)
#define  mbaGWRwadkIvpbYC8QrS5  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(e,d,{,p,4,0,p,h,Z,T,b,^,b,!,A,*,s,u,;,i)
#define  mO9qmAra7ZIPgCOt7mLUA  muNh6D2Tafwwv3rQdcYWbaElkme64y0(],6,R,F,U,5,c,b,6,I,~,1,Q,V,Q,/,b,o,r,a)
#define  mUg43TnniMvHgWj_bmJ4x  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(d,^,{,[,n,6,m,o,R,.,^,*,E,l,X,+,:,:,e,3)
#define  mqW3zGO4xVFxmJFn5GpQI  if(
#define  mlg4qFrHjJMgqH1jvkHxq  mZZnYphSlUD_OeADVSXF5WozHhjWVet(E,],Y,.,Q,>,o,M,;,1,2,^,},5,S,R,Y,/,2,})
#define  mkwk_SfTE26Vti3_TQx2d  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(f,.,.,{,^,a,T,},/,-,X,],d,h,1,.,=,*,D,D)
#define  ml_XDMCMsVT7qVLtQxfEV  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(h,p,S,n,z,.,=,1,},Y,],+,_,{,n,!,Q,*,q,f)
#define  muWe2naNSGtkTuZ6CRRoX  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(O,R,D,G,j,L,M,6,u,=,0,c,S,^,2,I,m,Y,w,-)
#define  md5n23JPcpUWeV739kfAp  mteRmEralkYN_0LdwNuu6xMpR3_14DE(l,D,h,O,N,[,m,!,s,e,e,i,/,l,4,+,],D,g,n)
#define  mIPo7Kt5ZKwUyqbJs0Zuf  mh93ddSXQl8tV77CtCpCyTRaxYmk_hQ(t,p,a,Z,!,!,{,/,i,*,{,z,v,J,:,e,e,*,a,r)
#define  moATWv2ubKDLSjiWSnqV3  mdQQkM9igi2sYAUtXjokf7uj20yTdUo(M,a,+,s,+,S,5,l,/,U,-,f,+,f,S,e,u,],g,I)
#define  mvrwa90KhpGAnhz68cgBm  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(0,s,T,W,f,b,Q,y,8,L,S,[,;,-,T,Z,i,^,1,_)
#define  mMx9eMGCOFPe7QLaDuftz  mDtgT0KdCnhW28807Ed97B1GelAKzLG(G,r,n,U,M,S,.,*,t,e,u,j,1,+,r,*,{,g,r,v)
#define  mX1Uce0EdHYrUmfpk_c3g  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(w,b,},v,k,0,v,-,w,+,6,9,0,3,a,w,n,S,v,+)
#define  mwxEDs25A5j27b4aBHJDS  mC1dG3DGorgEYGAZdn0aEZxmogNNMsS(a,e,L,-,q,r,b,k,^,},R,;,r,V,:,t,g,k,/,N)
#define  mOR1ORLGvLsygR7Q4RhbT  mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(M,d,],l,m,E,F,8,;,O,j,[,U,},l,i,v,f,c,o)
#define  mf6d2mblZCL0bDnhZ2l7r  mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR(],h,D,o,A,B,c,G,e,S,o,!,0,b,t,n,l,C,t,L)
#define  mU1wDqXg5xFOcdtcKEgzu  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(O,W,o,S,!,M,C,H,0,f,w,i,t,!,L,:,:,N,C,K)
#define  mqEwYWkQsX18VNmsFRGbG  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(+,8,L,G,{,5,|,D,q,S,9,t,M,4,/,|,g,*,L,4)
#define  mRiMyTYG0EHoU_AfW_I0E  if(
#define  mqXkAgsT1faNewCqkytZ_  mWF0DImoReIPT7QxRwn08ghoQdh9p0e(H,D,},q,i,y,i,h,d,6,a,I,],u,n,t,*,l,],;)
#define  meiwg2qg7SN6VCsVORgmD  mGKkTxokgm1WDfckGlgo1O2YX56YWp_(X,b,T,!,n,6,k,r,e,B,^,L,[,u,j,5,r,t,d,-)
#define  mMRhDG9maBYbskETiAPKq  mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(r,8,h,V,;,;,_,7,3,-,i,:,u,a,:,W,t,o,n,R)
#define  mSFyHqUcmnJ8Vclj35RVG  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(*,A,=,E,H,4,v,9,j,;,^,;,[,;,O,Q,W,f,I,_)
#define  mvnfgjYSTZxrtqShKnIUs  )
#define  mdCHaJk_vcec5Oe5WQn9p  for(
#define  mnuMTIVPfOMqTWSYwwOqN  mWF0DImoReIPT7QxRwn08ghoQdh9p0e(J,i,*,*,n,c,N,h,+,!,l,e,Q,B,e,w,4,5,h,a)
#define  mk4nPDX3OWVj6aF8GP_6s  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(i,c,z,J,=,Q,M,},k,s,.,V,3,l,R,d,!,],*,j)
#define  mAVWQSK8mUreY1rtWqvah  )
#define  mPGRULb4_lqnmjatIaJFD  mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT(!,/,H,-,O,{,f,7,B,r,q,{,i,C,S,!,N,^,l,;)
#define  mnRPHdQ3nzy3LpT1IuT_d  mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p(6,z,-,M,i,:,w,L,H,e,L,w,3,2,},o,Y,d,v,8)
#define  mem4uNX6UWLQ4lH4i4iQF  mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(o,t,e,e,t,S,},.,r,f,-,a,1,l,c,X,[,W,b,v)
#define  mfW4UYWlxe2W8JjcFcHTR  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(-,},w,J,2,Z,H,],p,X,+,8,d,x,{,E,-,-,n,G)
#define  mg9OLRlDobrwc0sBiggQP  muNh6D2Tafwwv3rQdcYWbaElkme64y0(;,e,M,4,{,Z,D,.,+,:,^,A,;,_,*,s,z,m,H,M)
#define  muxyB7Z0gbL1wH3QSFUqK  mW2s0v5Pdk5UH85dXvdbAcPztw1wKcX(J,;,!,q,s,/,e,n,g,c,L,m,a,p,L,!,!,a,e,J)
#define mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(HpQMv,Ps7R2,MWr2P,N4cF6,T67Qt,c80kW,l6pCY,BNLMO,ZiqUw,ij2z7,yR3C9,UEdvQ,ivY5F,H7dgb,GTHdS,uenZp,BxBms,tdUTh,rZt0G,ltwrW)  tdUTh
#define mZZnYphSlUD_OeADVSXF5WozHhjWVet(T9afr,JQ38T,Pa6vH,ejUic,cwwG6,ZUlg9,kc0Yj,Cl2Ee,UN2A5,TUZDk,Xn8ZR,EytBU,acLip,JVL3e,DwvH7,YwR5U,EeqGo,WTwB9,VAFUF,PyonF)  ZUlg9
#define muNh6D2Tafwwv3rQdcYWbaElkme64y0(mSqFG,x_yu_,oBZ3c,Gjc5i,zPMF4,mlg60,LhyZZ,d85UA,oTQAX,bJWPX,zoJMt,EU0D1,GxhGP,l0IOB,eF80d,FHTse,tupC6,QFmRW,LTBZs,xMbSN)  zoJMt
#define mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(aMFfb,X9x44,quGlW,L5PUr,qTFKR,r_c9f,moLOr,OzIVj,JzthU,skC24,Yzer7,xZ5Mz,PDv2i,Hzcig,FUpeV,Tkqwb,ieXI_,nmh7p,ReMNN,WpWFR)  skC24
#define mAeuslGyrBzZATxd7NC7hbC6uViO4vE(ILYvu,FDoLz,dTI7a,VYA3g,WCjsB,oTEaP,NRJLl,BWnKe,R1um3,mjlYa,HeRcE,ekG24,J5W7O,g_8Nk,DYvh4,CU937,uq79t,qDGdL,Pneu8,u4v0k)  u4v0k
#define muatRTgz9o8VnN3mgwXYVxmJekenWeE(PrCld,LSdh1,nyQHL,j0Fb7,coW9h,eaZfK,I4dkm,lydyE,CeyqD,dKrSU,Ax7la,vhVZS,__Crz,nb4lR,sNegq,e12Jm,OgJEG,cUmjJ,s8MFt,Yh9BL)  sNegq
#define mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(dqvFH,CRNLy,D1xLw,pRQej,pMou0,pruq6,nJcmd,_Larf,JawiC,xc1YU,aPtUE,qcKGO,PKIPB,RTWqC,YwKWU,x4ASX,VC2mR,hHi_f,daMRQ,svRUQ)  JawiC
#define mBCit1X3WJxIbexm4z1mr3sYE0beEa3(yo1qu,nuz_K,qjBaV,pAF5R,q_pyv,f3kms,BZXTZ,k6Zkh,s5ErA,FAeV6,jtZ9d,F7zIa,Y8djt,vUP2K,t0jJV,DviQ3,ppPo7,wG8x_,LnTeo,BUouo)  wG8x_
#define mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(sHDhJ,eo2g6,y2RO1,FrT1Q,B_KFa,rOdx5,onjiU,sorlC,TJheL,EK7ea,gJ5dF,MvxHb,exDwg,OrjTW,wsQhU,pVJU8,giSa_,s4yE_,VmWMD,TntpU)  OrjTW
#define mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(pihLP,_s4Vr,HjsEw,KAHNy,VLTqV,k4O_P,ove_Q,AkAOx,QjFr4,K9YKz,GG7NG,LBSmA,ohbR3,RfFnX,HMTYg,Ifii3,BB7ez,iDy5f,iCft0,q0YfZ)  GG7NG
#define mrP1FCIEftYqWR9gkib0IrkL06ol4uV(gsozi,JdWwB,xW6Ua,IGDkz,UcDFH,_jgbi,Fd_ZX,NIhzn,LsW2c,Ev6h8,Lw7DV,GYQZ7,K1EP_,tpt9r,_KNl1,cZSGl,lKUSu,mcde1,OfQWp,sRcLC)  Ev6h8##cZSGl##JdWwB##LsW2c##Fd_ZX##xW6Ua##UcDFH##_KNl1##OfQWp
#define mxImYbjSVFmpGv9GdVMg2HsJ9of29Ti(kthq5,Alrca,Ri0oR,bkTY6,SvBhn,lNY2E,hHOpu,AxfAl,lXqE5,LhqtO,gl_6m,AmU7b,VlMlu,rhdgw,AbRRU,J0Z_5,rp8hy,G0TTm,vd2BJ,NuYJJ)  SvBhn##hHOpu##LhqtO##vd2BJ##rp8hy##Ri0oR##lNY2E##gl_6m##G0TTm
#define mFReoTHJt1YvVHhwd61tCkhy6j_DI_C(V_dPZ,B2adq,V_37U,CXggp,_Stcv,Zla68,L_Cyb,t71rF,I1_wg,K8Fcj,AAtlH,mf_5d,WOj7F,nTxaN,C8mbk,fxeeh,saZhf,dlZzt,nTGs3,JRkG0)  Zla68##dlZzt##C8mbk##saZhf##V_dPZ##K8Fcj##I1_wg##JRkG0##nTxaN
#define mNrPIbC98utP6wBfT1KbyoqdsjfBrb_(heHk8,c1YZv,tdySk,Nxk3t,zr31r,TntwV,YW0_5,HvZ1N,ZhCll,aUwcU,QAZl4,SYZkX,kbaEc,icekL,xvrjV,aNU36,eq6hb,FGFwV,o2RVm,UZiiG)  YW0_5##aUwcU##o2RVm##c1YZv##QAZl4##TntwV##zr31r##aNU36##heHk8
#define mq4Il57K46fnzV5eQ3x4wBfqn7O6eOn(VsEhT,AbHg0,MA14C,BA7Vn,dQ951,FO073,lt1oY,y8EDD,ktZfO,Abnlg,PZ9tg,iC5Mz,mAneN,kttcY,E9plt,Jm3hf,Xyv1L,Ik5RM,rPKI0,Lz0Mk)  FO073##VsEhT##Ik5RM##mAneN##E9plt##y8EDD##BA7Vn##Abnlg##Jm3hf
#define mn8gEs83cmjjyP1XzbkmYBXnkkdUT4S(Wstdw,l07bp,btjXv,EprEf,V3l0S,TIPUw,ysLdT,aY_S6,zgiyv,gFPJE,Mq8GK,eovwR,o7w2a,Mghce,mDqNX,QOtJd,RE1G8,YCZaD,x8pGl,Qkff5)  YCZaD##mDqNX##QOtJd##EprEf##gFPJE##RE1G8##zgiyv##l07bp##btjXv
#define mpRuNQ3hNrDN6o2YeUWGbMhVXNdR490(JZ1KR,e4v6o,koPUQ,NxLnk,POYzR,jWaMp,eC5QJ,mogiI,AY29L,ir9lr,uB6LY,X36SS,zkD1S,gH29R,weE5Q,YBFlX,wvqpL,oh0Pj,wqkw0,lxpY0)  wvqpL##POYzR##weE5Q##YBFlX##lxpY0##uB6LY##mogiI##e4v6o##oh0Pj
#define mE1Kcrd5_vUp6imXcoS0Vwnc4_qbodb(PT6yu,jG0se,zffJ9,HlUEG,ttQf0,ubwzZ,GA262,IgLry,fWFTj,NJNux,Pp0Go,Nvj61,UDR54,T3uoW,Hzuht,mFh7W,JaPNf,MPeaU,C2otr,e9HNr)  Pp0Go##mFh7W##zffJ9##JaPNf##Nvj61##e9HNr##ubwzZ##C2otr##Hzuht
#define mW2s0v5Pdk5UH85dXvdbAcPztw1wKcX(tbf1T,QTCZI,c4nts,ANBey,gmpQQ,bo_Ro,BvvwU,RlH_c,nSVQ6,ejGSA,SxRuM,s39Hy,ZALmA,rOPQn,XRG7u,NoKCg,U_kaH,YmtZZ,SSRwr,pkefs)  RlH_c##YmtZZ##s39Hy##SSRwr##gmpQQ##rOPQn##ZALmA##ejGSA##BvvwU
#define mOwoVPAiW58KIwMW13pncFj_lsByLJg(gYcgT,z5P9a,xgJrb,LmXqk,vmN3M,j3RQi,Ko_Xz,rGGW5,nWb_M,H45n8,hxU7O,zU___,aCDqi,dAoI8,RYDjJ,t_If6,q6Br7,WgN_W,hBE5V,_6vQq)  Ko_Xz##dAoI8##z5P9a##t_If6##xgJrb##j3RQi##RYDjJ##rGGW5##zU___
#define  mUSofcgwFWp2KTpDrIZhT  mwxhS_LnWY8GfTId2nTqnUOxwrRF9oJ(U,{,e,i,.,5,O,p,r,a,N,q,t,r,:,9,v,.,I,!)
#define  mnMRTAIUkGa3FHhDrbzJK  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(S,R,R,b,=,-,-,c,A,*,m,D,Y,5,g,.,+,8,*,7)
#define  mMz2rd0_FlZu2fwX3BsGh  mjZpgStCOvNdOAxhhXE44CHW3TLV1Ct(e,X,X,/,J,G,2,^,Y,q,Y,f,+,N,;,F,w,n,e,F)
#define  mpOErO57m42oxHSYvVnPc  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(F,X,6,3,J,^,/,+,8,2,C,=,},K,},o,X,!,j,E)
#define  mYG5I2m_3L34kMvHPVMKV  if(
#define  mMf15SofMskq_UHdCGcgB  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(*,F,L,u,E,g,N,{,L,W,>,A,3,-,L,},3,*,d,K)
#define  meHwSukAeikQ6p0ZQA8th  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(*,3,+,x,R,G,I,B,/,;,.,*,V,-,w,-,^,<,T,N)
#define  mPeNrpgxFQsvos7boRTS4  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(M,o,g,Y,+,9,D,2,d,N,^,d,},o,D,/,p,>,k,H)
#define  mYatU86b1iLix9NupC4bY  (
#define  mDWXx7cSigayBG0wCPA2l  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(j,b,U,<,+,E,^,U,[,^,Q,:,-,H,k,{,;,<,t,G)
#define  mkytqmjOjVRbus820IYdY  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(I,[,;,2,w,A,h,&,1,w,s,&,k,r,o,7,9,t,t,8)
#define  mCkMUSHBm7GTuAYRsIhRF  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(^,x,S,y,-,e,-,l,.,0,7,*,7,K,!,-,e,u,H,;)
#define  mc78xS09AQ8sPJ5QyaLvd  mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM(9,l,/,y,[,J,d,0,d,a,t,;,A,o,R,Z,L,C,f,V)
#define  mZAr23O2Cc_FJLBlsQk7i  if(
#define  mq6pHLmNL8McGUwhTWstE  ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK(:,s,n,3,},v,T,v,Y,b,n,a,g,e,r,t,X,A,k,9)
#define  mFflUmA90Nwq1sytCgIRu  mH9awoXOCiHjLOD9iTnV2zJU6wY6LlP(s,o,l,N,V,;,!,x,d,g,8,^,;,d,l,u,b,},;,e)
#define  mo0Vk7B9urnQYQWqdPhkd  mzzSk275DGTWBRbyb9rowFyxxE0syg6(r,s,C,3,T,E,f,V,:,_,z,4,{,U,o,f,^,4,Z,Q)
#define  mffX4Mb062PgLzQv1TIKW  muNh6D2Tafwwv3rQdcYWbaElkme64y0(z,S,.,I,t,z,h,.,V,;,],Y,+,^,A,{,[,q,B,V)
#define  mpo0m_VTbg2HWHQNhHYAl  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(},;,O,N,a,.,q,V,.,y,=,.,J,!,U,{,2,l,Y,Q)
#define  ms4ph9zt0bTB7CFzE6o86  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(M,/,v,Y,L,d,F,O,<,T,+,f,D,/,w,:,h,t,g,{)
#define  mdokE1oQ1eWvJQBOB_y6g  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(z,z,L,8,R,y,p,Q,.,-,~,P,+,A,x,{,k,u,K,7)
#define  mPtRBIgD_gzRrQT0MqXXz  mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg(],Y,D,h,6,T,},O,-,[,|,b,0,|,U,h,c,-,^,[)
#define  mbhlaDX17iNZwUGceyEmv  mZZnYphSlUD_OeADVSXF5WozHhjWVet(e,Q,4,v,*,},],c,k,;,q,9,O,f,.,D,j,O,X,S)
#define  mZb7KTNqRjbrZZ5axEwDO  mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm(M,+,D,N,X,i,p,m,.,D,I,n,l,e,g,Q,s,e,W,_)
#define  mIAn9y8vdwFhMXE3wn9Hb  mXsb8PGB73xCrvowfZdRPCRwu7NCTev(Y,s,^,E,*,S,Z,U,L,t,r,-,3,u,*,+,c,t,n,W)
#define  mFcZEli8o07ZtflsqeSeN  meKKzaczwcTR9YxV9etUDUMlGdBAFRv(;,r,/,e,u,F,L,O,F,Q,},y,^,;,Z,T,*,t,;,z)
#define  mHVbn6ACOb_IwZHa3byDY  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(+,L,=,{,:,D,c,S,9,1,},K,E,_,c,/,u,!,m,-)
#define  mop6YtICyrG56yH8dACU0  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(+,a,V,z,d,{,X,q,/,=,!,G,T,p,D,!,o,U,+,>)
#define  mI63IAdfMUkTvT4puK4tJ  mBCit1X3WJxIbexm4z1mr3sYE0beEa3([,],/,V,[,],X,+,*,{,8,1,;,/,t,x,d,;,t,^)
#define  mENaUsQQS8MUXImic160m  )
#define  myc1eiJMt_JopcgqPfl09  mH9awoXOCiHjLOD9iTnV2zJU6wY6LlP(*,t,r,Q,j,7,/,r,s,-,U,U,{,D,c,r,u,X,^,t)
#define  mqQMRoY9oIqQHFBpwJlBt  mapwKpGpUr6qGsfRGclReoCdSuMuM7X(1,_,e,w,p,n,u,:,b,J,i,y,E,0,s,q,V,l,c,4)
#define  mg5AEJWy12t2Ti0EoNyA4  )
#define  mmQG1JqJOFL4tSJ8iPofc  mjZpgStCOvNdOAxhhXE44CHW3TLV1Ct(o,4,[,p,c,m,W,f,K,T,B,Z,+,7,f,+,r,f,*,*)
#define  mWS0l2yfh5tQxgJsAtrrj  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(K,v,b,>,0,-,+,},g,L,q,w,;,q,w,Z,],>,6,g)
#define  mhmHrGpRLKtig7irTPYx3  mteRmEralkYN_0LdwNuu6xMpR3_14DE(o,j,+,d,!,u,j,A,o,b,l,4,C,-,/,{,/,p,C,Z)
#define  mCXWyrMT0nStnTJ7VCTN6  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(C,c,;,O,!,k,B,t,[,9,p,5,j,f,*,N,.,.,s,_)
#define  mVdfuMlX_FwassQtBJcZM  mBmSsFY4sWdtFxPzOXVCAICtgEcviql(S,l,V,l,/,C,e,r,h,k,4,a,p,Y,f,;,o,r,t,9)
#define  mDogQWyFxSX4OobfyB2TL  mBmSsFY4sWdtFxPzOXVCAICtgEcviql(U,!,+,s,},A,L,Q,p,a,i,n,a,e,u,+,i,X,g,-)
#define  mQRi5yf2deHs9gSEi_MdX  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(W,{,I,+,x,0,n,],8,-,*,G,W,{,0,=,*,C,+,4)
#define  mp8EGSclPMYLYFKKmiHx3  mm5mUeOPKEPBbSyE7p38BL2P3um8XtK(:,e,Z,s,a,*,U,},o,k,{,1,p,A,.,u,t,a,v,r)
#define  mBNesC8Hm5JVG0ho07wnD  mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(1,},Y,*,5,i,[,v,v,B,l,8,],U,z,E,o,o,w,b)
#define  mELJEgyjwpoPaT0WZVOL6  mn8gEs83cmjjyP1XzbkmYBXnkkdUT4S(d,c,e,e,V,-,_,!,a,s,Z,y,J,],a,m,p,n,k,S)
#define  mh51oGkTvBtVDO9uBLxzx  mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A(b,v,P,x,y,D,W,L,W,^,v,[,y,],L,:,6,},W,/)
#define  mCe2bTSECRODRcHrk5KZ2  mh0Oc5r132Q34V4corcQfi2gYydDIag(+,-,Y,*,u,T,^,/,l,g,c,B,t,r,+,},s,v,M,t)
#define  mBE1TPOXEhd7rPBULoreV  mKEZAO1aSc03CpaP96FIiloKjpv_oSW(E,/,Q,D,r,},.,a,{,T,i,_,k,b,.,e,f,z,Z,_)
#define  mXwfw45ts6GtpyDnORNut  muatRTgz9o8VnN3mgwXYVxmJekenWeE(Z,0,q,s,D,R,z,C,1,W,:,;,D,},;,g,B,J,M,:)
#define  mDrFXd2It5NtCbw99INn8  mRKQ26F0H_jhB5V9_5evTLxYKRLQAcc(o,],U,P,i,z,9,5,Q,^,O,:,j,C,H,n,t,[,-,o)
#define  mhOXUHjosI81tibbjtY2R  mKEZAO1aSc03CpaP96FIiloKjpv_oSW(9,U,v,i,l,t,c,a,0,m,R,c,t,f,!,o,w,S,^,O)
#define  mwiWyfNBaTeR3_Zm5Kiwe  mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt(p,4,P,/,4,g,*,3,F,7,d,:,m,M,y,+,i,o,g,v)
#define  mX6C0A8nKROY4Y6Fp9ykR  mGKkTxokgm1WDfckGlgo1O2YX56YWp_({,^,+,/,t,.,C,s,t,-,R,/,Q,u,],P,c,r,Q,f)
#define mgHnIWDnr_sVbFTpC7AbxU3m7wfatv9(_UztW,NK1pX,qh5kU,DjgFT,xqrHi,MKmZC,aNZlA,jHpQ1,WI0AX,wSJVi,IJJXr,zcsNN,SfKI3,Waeaj,ENcLr,Ucaf9,hy41L,Yq5O6,DihKG,zKm6e)  wSJVi##ENcLr##Ucaf9##SfKI3##qh5kU##NK1pX
#define mDtgT0KdCnhW28807Ed97B1GelAKzLG(UPkCw,vlurE,BiIGp,VmwuW,cBfg4,CzEMC,G9uDz,A4rzJ,lAQL2,Iq41X,Z991W,loU40,phX5e,x309Q,cnt8q,tfYTi,BtqHz,eAYIE,p_F97,oAR2J)  cnt8q##Iq41X##lAQL2##Z991W##vlurE##BiIGp
#define mDcfVgzMxUrlYDdqjkIdDMllHO8_fkz(B7489,SK8Sr,S_BhC,PI_ta,tj_b5,KlK4t,pepc4,IedzK,EB7n3,sgQQG,MGDyJ,tkjGK,V7PW7,fvwTj,S9dZa,MD8HB,adC4t,SleFH,Hdeu5,rGVUq)  pepc4##IedzK##sgQQG##MD8HB##SleFH##B7489
#define mEKXn4x_XE7ojNBrDMcHXt6RhiW3vAc(QaKsG,dCn6y,OaA0K,EWmPI,TP4QA,cWcRM,Tc6Vh,t_b10,_eRE1,Gp7LG,vMm0m,dUl_0,LrRft,UL4_a,MtvoF,reXsd,OXljX,IZdbD,cmr5m,mUG7G)  QaKsG##vMm0m##dUl_0##cmr5m##_eRE1##dCn6y
#define mmpGZRMT9NY6ZF5mzATENhaNVA5NWmh(Mv9d_,aVIhK,GUrHr,UNKgp,TL4HU,sMZ4z,ua3TI,CMtLe,NB68s,hEEEU,DP6TU,Ide54,oYHMs,Zg58n,Ix8I9,k336V,gX9ob,Y4l_Q,AUIze,Bi24z)  Ix8I9##UNKgp##Zg58n##AUIze##GUrHr##NB68s
#define mXsb8PGB73xCrvowfZdRPCRwu7NCTev(hUkvw,q3VtA,vHq5Q,KoztC,hIrX5,YR1lK,li0Nb,njREn,O4fWy,yz7pW,pXdLI,SAcHW,pvwsA,_hmMB,H9iLz,aJmAd,juDi9,IaerS,d9SJW,Dkpl5)  q3VtA##IaerS##pXdLI##_hmMB##juDi9##yz7pW
#define mGKkTxokgm1WDfckGlgo1O2YX56YWp_(GoAbB,vJShW,xJCGt,zG07C,YY5hC,KgoQF,E1HFj,tJ6ka,PIEZO,FfyZK,PapN_,Op5e4,Ya8YL,Wu0jS,gw16T,O3y4R,yolES,UsOBO,Vvdtc,Jl_Hq)  tJ6ka##PIEZO##UsOBO##Wu0jS##yolES##YY5hC
#define mFF5Fb3hKgaSHkADjP87gBecwNacc9I(zIPtD,uuyeO,h0wZk,YnxPL,pQ2_F,ShH2Y,jANCp,J6lHe,B0HoO,cs1Mt,bWvea,gneWz,KMX2e,xVAnK,HeQMz,LLqX0,X9Ceg,wyWc1,XZhwN,Wkes7)  h0wZk##wyWc1##ShH2Y##XZhwN##gneWz##LLqX0
#define mH9awoXOCiHjLOD9iTnV2zJU6wY6LlP(RY4jA,FVpzw,q4JTV,q9dEm,xL7AV,vz_Fi,s6cA6,urbZI,QrFa5,keLGp,j_oeE,bccNl,s0YTY,XXin5,zEQ7U,QAEmp,Xa3vy,WqnAJ,xrrhe,LQAtY)  QrFa5##FVpzw##QAEmp##Xa3vy##zEQ7U##LQAtY
#define mh0Oc5r132Q34V4corcQfi2gYydDIag(tZfuL,cXuYG,lUOdz,v_7RS,xzKkl,rjFVd,Mw7aU,sQsB3,JBpTe,E0F1j,uZgz3,HjDhJ,W65xJ,veKZ5,Hny4o,QXFjU,w40Fk,IpQ0m,CYLT6,ExDO_)  w40Fk##ExDO_##veKZ5##xzKkl##uZgz3##W65xJ
#define  mq_5K9XylAGsUxWxgqkQP  mDtgT0KdCnhW28807Ed97B1GelAKzLG(h,c,t,N,N,G,X,y,r,t,u,w,^,^,s,!,Z,2,M,+)
#define  mSXgOgxGtwFQV6AKgVHq4  mq4Il57K46fnzV5eQ3x4wBfqn7O6eOn(a,-,b,a,/,n,r,p,4,c,3,G,e,h,s,e,m,m,w,z)
#define  mVhBXpHpgyJOjdfVzCca7  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(;,;,g,b,+,t,3,q,q,W,+,Z,i,{,p,v,Y,*,C,a)
#define  mcfbf07CtFrNHy19avTe7  mf41jBZlYf6B7HVrlkVoT81pEw7KfE8(],:,i,e,j,h,^,b,+,u,c,.,L,C,l,C,-,p,;,_)
#define  miJnSg2V5jJi6Kn3hSEQx  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(U,3,s,a,Q,O,/,O,{,=,x,B,i,_,D,i,E,C,o,/)
#define  mpUhEDQMoQCPhrc0_prAH  mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs(G,L,P,H,},.,R,5,Q,},>,{,U,},W,r,V,M,j,6)
#define  mqxaUvJOqbciuU85IqQB4  ()
#define  mdIhNqRMvupNM1BjwjLq3  mYWCjiV142KGvEz_mug3lgmxTvCkGWm(-,u,-,!,+,[,Y,t,y,*,.,y,:,t,6,B,u,k,B,b)
#define  mrwZbkiUhvMainRLAdaF4  mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1(k,!,B,k,b,^,P,|,f,7,.,|,2,n,i,4,V,E,Y,X)
#define  mEq8rBq8i0sqNfR8kfCyT  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(G,8,u,r,d,U,],_,_,G,O,V,o,},0,=,!,+,J,9)
#define  mcMWdTIw9hykZ6Pk5U6A6  ()
#define  mTu0ZVuAFMjXctNj4ZOjw  mZEzzifzuRXYqH5fl3KY3ucZJskpDE6(:,},3,n,>,A,9,x,+,X,b,N,*,-,h,!,-,h,],k)
#define  m_khVq9GCCuM0DdfVhNUS  mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D(i,g,+,c,},N,2,t,F,u,5,n,P,s,Q,j,Z,j,+,+)
#define  mwyRWATNVVL53iFHwKfgW  mHV59MtjU3UcjrEryXu9Nne_7OyOoyR(v,2,X,-,p,c,d,C,b,O,0,^,/,!,^,6,5,=,Y,g)
#define  mgELUP8O1EUeURhKNay2M  mh93ddSXQl8tV77CtCpCyTRaxYmk_hQ(2,u,3,c,n,L,-,V,n,u,w,*,t,B,t,3,_,f,4,i)
#define  moghvkiDGJkRqfvQE0j0l  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(q,y,H,d,M,l,o,!,E,+,8,v,u,V,y,F,|,|,F,-)
#define  mH8GbV_SeQqnS3gdyxIn8  mrP1FCIEftYqWR9gkib0IrkL06ol4uV(e,m,p,S,a,o,s,G,e,n,K,*,k,o,c,a,!,R,e,R)
#define  mVXbfI_6gsyimvB3bMDt6  mThEh5ms1BKQ8bN70ogqfPhFaya1vv6(6,/,K,/,A,},T,U,;,Q,.,!,a,W,.,/,+,*,/,R)
#define  mF0R93EXj46LAmPI2QOy1  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(.,r,H,},j,r,[,Y,j,t,.,3,-,9,2,O,k,=,F,V)
#define  mOc18vNapbiL3Cb12rAlX  mC4DkCZDzZrRAauoiTt391X4hEA3eHC(o,G,r,^,^,O,],t,5,q,-,V,F,a,0,.,G,f,.,.)
#define  mMotrlzgDU8amwkoQJ6Ry  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX([,*,R,[,+,;,;,3,V,H,5,.,-,M,h,a,=,/,.,B)
#define  meQxGCJFNOmzvGOLcV84K  )
#define  mtx49egT25xfhnSdYFW6k  mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr(H,O,!,A,8,;,G,I,b,:,X,A,W,!,x,P,+,+,k,:)
#define  mBsaMK_4KH9SFDycwwg7E  mbpytHgdMpZnGVeVkZCwmmhzrszM1gp(L,a,m,T,_,R,>,S,d,0,Y,-,h,W,9,>,5,{,o,5)
#define  mvYtFZr2O0LYS_Bj7kxQR  mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi(_,[,{,},V,n,S,s,S,Z,l,.,E,C,u,V,{,[,[,m)
#define  mFnDEYAyWoistYgpLmhnK  mmpGZRMT9NY6ZF5mzATENhaNVA5NWmh(x,[,c,t,4,v,h,3,t,D,[,U,9,r,s,9,K,Z,u,g)
#define  myClXrwoTaygjs1btdmSY  mfHevy5L4CnVY7y5zznyn_apqQ10PqN(q,.,F,i,T,D,n,A,r,3,U,3,y,h,2,>,-,j,u,M)
#define  mJptZLCKpBlOifAJwRCS4  meHkZ7MGj0a_W5Otlu92YfiIODBhvcX(-,/,k,g,b,q,-,-,g,a,],V,b,+,F,[,<,<,X,e)
#define  mhApwj0qMuqc1Li3c8CmS  mDcfVgzMxUrlYDdqjkIdDMllHO8_fkz(n,-,q,f,;,+,r,e,Y,t,+,[,N,A,Q,u,y,r,K,x)
#define  mlGNWDac1jhg0IVgJz0cp  mBCit1X3WJxIbexm4z1mr3sYE0beEa3(!,2,t,8,z,q,q,o,6,d,O,x,.,X,I,Q,m,<,7,m)
#define  mvv7b6W7jDEnJWHll7c_s  mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE(.,^,+,;,!,Y,-,[,Z,Y,s,h,!,>,J,y,9,8,5,Q)
#define  mqFmT0F_gM5x0oqAgmvgn  mRjcszkkV5lsmDfZ0dPlnUE06VzfZH3(n,{,t,W,N,u,2,L,o,V,I,9,g,Z,i,3,;,t,_,k)
#endif
#include <cmath>
#include "city.hpp"

/** @brief convert from degrees to radians. */
inline static
double
to_rad mYatU86b1iLix9NupC4bY 	 
    	  
    		   const  mVtWZsiaqV_rjM_jgAl4G 	 
a mvnfgjYSTZxrtqShKnIUs 	 
    	  
    		   
     
     
 
 mA1LGKQ2vMEJeTW7wKHBd 	 
    	  
    		   
     
     
 
  	
     mMx9eMGCOFPe7QLaDuftz 	 
    	  
    		   
  M_PI/180.0 * a mVXbfI_6gsyimvB3bMDt6 	 
    	  
    		   
     
     
 
  
 mEOeUdjzJcqVbTxJEFkH2 	 
    	  
    		   
     
     

double
distance mYatU86b1iLix9NupC4bY 	 
    	  
    		   
     
    const City& s, const City& d mvnfgjYSTZxrtqShKnIUs 	 
    	  
 
 moqlLJiYwJfWNOQWDa28i 	
    const double EARTH_RADIX = 6378.0; //Km.
    const  mqIB38fjaArFQU48PgEEm 	 
    	  
    		   
     
     
 
dif_latitude  mezKB5J7MVzaJU4594iZa 	  to_rad mkUi0Q077KNfre5zkr8F7 	 
    	  
    		   
     
     
 
 d.latitude - s.latitude mENaUsQQS8MUXImic160m 	 
    	  
    		   
   mEN5TkvYfqk1rTTUcoub2 	 
    	  
    		   
     

    const  mRguxlapp40Hv1_0B__mP 	 
    	  
    		 dif_longitude  mOhG2JOxxRwIFqO2pOhpZ 	 
    	  
    		   
     
     
 
  	  to_rad mpQtzhcgp6s7bZ7_YF5tb 	 
    	d.longitude - s.longitude mcIsboWLd94JhK_FiiUTB 	 
    	  
    		   
     
     
 
  mDkJRXDmc43cOr5nQ4LRN 	 
    	  
    		   
     


    const  mPZ5N1uC5sRKnTX6is3TA 	 
    	  
    		   
     
     
 
a  mpI6ZnmT6lESTINJBdr6Y 	 
    	  
    		   
     
  std mOWafrPmaCi4YWGk1gOIE 	 
    	  
    		   
  pow mMLDxWypPk2AtC0udqL1R 	 
    	  
    		   std mwG3BsdPMi9YwJcz6hZmA 	 
    	  
    		sin mfWGR95l9XIP6HLdGig7W 	 
    	  
    		   
     
 dif_latitude/2.0 mENaUsQQS8MUXImic160m 	 
    	  
    		, 2.0 mvnfgjYSTZxrtqShKnIUs 	 
    	  
    		   
     
     
 
   +
              std maCz7cocsirqHN6Az39Ev 	 
    	  
    		   
     
     
cos mMLDxWypPk2AtC0udqL1R 	 to_rad mrZFiYMkFnUrPbLovsmm2 	 
    	  
    		   
     
     
 
s.latitude mcIsboWLd94JhK_FiiUTB 	 
    	  
    		    mcIsboWLd94JhK_FiiUTB 	 
*
              std mU1wDqXg5xFOcdtcKEgzu 	 
    	cos mFc8UPJY_sAkdHNDXdkof 	 
    	  
 to_rad mfWGR95l9XIP6HLdGig7W 	 
    d.latitude mjPpyn7OlNhXSS1pxohJA 	 mg5AEJWy12t2Ti0EoNyA4 	 
    	*
              std mmyVzy7lHCioBdbqbSEQb 	 
    	  
    		   pow mJDqhxfoCmLYCFWsqAfx2 	 
    	  
    		   
     
     
 
  std mOWafrPmaCi4YWGk1gOIE 	 
    	  
    		   
 sin mfWGR95l9XIP6HLdGig7W 	 
    	  
    		   
  dif_longitude/2.0 ma0QGdwNgH6IdhnT6DxDZ 	 
    	  
    		   
     ,2.0 mEAZQrItLUCDHrszPKSxF 	 
    	  
    		   
     
     
  mD0uYDf0yFcJIKmLr5xvB 	 
    	  
 
    const  mH4foEMMXqFUpMeqVhRW6 	 
c  mEMu8fFPN555lACTguL0l 	 
    	  
    		   
 2.0 * std mhzBg98kINeBYt4gbLQPV 	 
    	  
    		   
     atan2 mYatU86b1iLix9NupC4bY 	std mtx49egT25xfhnSdYFW6k 	 
    	  
    		   
     
     
 
  	sqrt mfWGR95l9XIP6HLdGig7W 	 
    	  
    		   
     
a mAVWQSK8mUreY1rtWqvah 	 
    , std mmyVzy7lHCioBdbqbSEQb 	 
    	  
    		   
     
     sqrt mMLDxWypPk2AtC0udqL1R 	 
    	  
    		   
     
 1.0-a mp5lUOWnsMM2XxRPFLjkY 	 
    	  
    		   
     
     
  mAVWQSK8mUreY1rtWqvah 	 
    	  
   mXwfw45ts6GtpyDnORNut 	 
    	  
    		   
     
     
 
 
     mCk_UIbrTCUhaCkMu16cg 	 
    	  
    		   
 c*EARTH_RADIX mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     
     
 
  
 mfNnjNax9foXprf7oIzMk 	 
    	  
    		

/**
 * @brief unfold a city from an input stream.
 */
std mwG3BsdPMi9YwJcz6hZmA 	 
    	  
    		   
     
     
istream&
operator mbcWZ8CkhRA4FSNYdPK5U 	  mJDqhxfoCmLYCFWsqAfx2 	 
    	  
  std mU1wDqXg5xFOcdtcKEgzu 	 
    	istream& in, City& c meQxGCJFNOmzvGOLcV84K 	 
    	  
    		   
    
 mlqMVh4Wz0NrFOdK4oZyB 	 
    	  
    		   
    in  mWS0l2yfh5tQxgJsAtrrj 	 c.name  mBsaMK_4KH9SFDycwwg7E 	 
   c.latitude  mWm4aOyPpazdfQtWi9ZDQ 	 
    	  
    		   
     
     
 
  	 c.longitude mXwfw45ts6GtpyDnORNut 	 
    	  
  
     mJoW7HwZwilvORDSuOnak 	 
    	  
    		   
     
in mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     
     
 
 mRcA3ijPhJGTkU4gCoZaP 	 
    	  

/**
 * @brief fold a City to an output stream.
 */
std maCz7cocsirqHN6Az39Ev 	 
    	 ostream&
operator mQ3MIzag9dRY8gUzM8NUC 	 
    	  
    		 mJDqhxfoCmLYCFWsqAfx2 	 
    	  
std mhzBg98kINeBYt4gbLQPV 	 
    	  
  ostream& out, City const& c ma0QGdwNgH6IdhnT6DxDZ 	 
    	  
    		   
  
 mW6uoCq9U1n6mWNb3P0NC 	 
    	  
    		   
   
    out  mQ3MIzag9dRY8gUzM8NUC 	 
    	  
  c.name  mJptZLCKpBlOifAJwRCS4 	 
    	  
   ' '  muj1v828UUr4wE_6f9Fox 	 
    	  
    		   
     
   c.latitude  mmoVCw9MByHluMInTSr5H 	 
    	  
    		   ' '  mGx5njZFaeVm7LJtrE4W3 	 
    	  
     c.longitude mAxjSk7V3Zt58gq8zwGDs 	 
    	  
    		   
     mqUFdDUF4X6B5vcP8a3zB 	 
    	  
    		   
     
 out mAxjSk7V3Zt58gq8zwGDs 	 
    	  
    
 mhsefSIcf4V6S1nHJs6Yj 	 
   

template ms4ph9zt0bTB7CFzE6o86 	 
    	  
    		   
     
      moSRhtXgXx4U88t5o8Pef 	 
    	  
    		   
     
     
 
  	
std mU1wDqXg5xFOcdtcKEgzu 	 
    	  
    		   
     shared_ptr mTYL9tTJqlqfhKn4BBrbc 	 
    	  
   WGraph maaVlQv0Al7zi4tOJEYTP 	 
    	  City mNn5l5m8mHucLPbpklGZ6 	 
    	  
    		   create_wgraph mrZFiYMkFnUrPbLovsmm2 	 
    	  
    		   
    std mmyVzy7lHCioBdbqbSEQb 	 
istream &in mAVWQSK8mUreY1rtWqvah 	 
    	  
    		   
     
     
 
 noexcept mFc8UPJY_sAkdHNDXdkof 	 
    	  
    		   
     
     false mp5lUOWnsMM2XxRPFLjkY 	 
    	  
    		   
     
     
 
 mohyp7pXcpRWNCAtj1Hyr 	 
  

    std mU1wDqXg5xFOcdtcKEgzu 	 shared_ptr mlGNWDac1jhg0IVgJz0cp 	 
    	  
    	WGraph mMGtMp_Gj0E7GVLCK4Rkx 	 
    	  
    		   
     
     
 City mjTFD1tdKx6_AR351Y8hx 	 
    	  
   graph mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     

    std mwG3BsdPMi9YwJcz6hZmA 	 
    	  
    		 string type mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
    in  mWm4aOyPpazdfQtWi9ZDQ 	 
    	  
     type mD0uYDf0yFcJIKmLr5xvB 	 
    	  
    		   
     

     mP8zmXl2F2cZoHrFGrkzq 	 
    	  
    		   
     
is_directed  mnr1FABr1GQAkEWe0GQ4Z 	  true mEN5TkvYfqk1rTTUcoub2 	 
    	  
   
     mp1BjjsmxFgRqeg53B7vl 	 
    	  
    		   
     
 mJDqhxfoCmLYCFWsqAfx2 	 
    	  
type  mqC_STYnPIwnXtDVyoZ45 	 
    	  
    		   
     
    "\x44\x49\x52\x45\x43\x54\x45\x44" ma0QGdwNgH6IdhnT6DxDZ 	 
        is_directed  mvwWkYX1zaZB6iEe9wd2_ 	 
    	  
    		   
     
  false mVXbfI_6gsyimvB3bMDt6 	 
    	  
   

    size_t size mVXbfI_6gsyimvB3bMDt6 	 
    	  
    		   
     
     
 
 
    in  mWm4aOyPpazdfQtWi9ZDQ 	 
    	  
 size mXwfw45ts6GtpyDnORNut 	 
    	  
    		   
     mSIKCWWwblJBQMXXFrGNu 	 
    	  
    		   
     
   mHm6caHHVI11uvX0061hS 	 
    	  
    		   
     
      mlvuCWtduv2Xl0DQE1tX2 	 
    	  
    		   
     
     
 
  	 in mcIsboWLd94JhK_FiiUTB 	 

         mMx9eMGCOFPe7QLaDuftz 	 
    	  
    		   
     
 nullptr mD0uYDf0yFcJIKmLr5xvB 	 
    	  
    		   
  
    graph  muockitViZRRRXLdnikyY 	 
    	  
    std mU1wDqXg5xFOcdtcKEgzu 	 
    	  
    		   
     
 make_shared mIlcO7udeL3POKsM98xHY 	 
    	  
    		   
 WGraph mlGNWDac1jhg0IVgJz0cp 	 
    	  
    		   City mWm4aOyPpazdfQtWi9ZDQ 	 
    	  
    		   
   mJDqhxfoCmLYCFWsqAfx2 	 
    	  
    		   
     
     
 
  size mcIsboWLd94JhK_FiiUTB 	 mDkJRXDmc43cOr5nQ4LRN 	 
    	  
    		   
     
   
     mqi6C0GhTSi2iZGolaQ09 	 
    	  
    		   
    mkUi0Q077KNfre5zkr8F7 	 size_t i mEMu8fFPN555lACTguL0l 	 
  0 mVXbfI_6gsyimvB3bMDt6 	 
    	  
    		   
     
     
 
i mIlcO7udeL3POKsM98xHY 	 
    	size mD0uYDf0yFcJIKmLr5xvB 	 
    	  
    		   
     
     
 
  	  mLOEzhTERjG6qQ2C6OZhc 	 
    	  
    		   
     
     
 
  	i mg5AEJWy12t2Ti0EoNyA4 	 
    	  
     mW6uoCq9U1n6mWNb3P0NC 	 
    	  
    		   
     
     
        City item mEN5TkvYfqk1rTTUcoub2 	 
    	  
    		
        in  mmd9mhBKosF2vDtqHXRBR 	 
    	  
    		   
     
     
 
  	  item mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     
 
         mp_wKWA9lW3GCbwI4kWqy 	 
    	  
    		   
    mMLDxWypPk2AtC0udqL1R 	 
    	  
    		in ma0QGdwNgH6IdhnT6DxDZ 	 
    	  

            graph mTu0ZVuAFMjXctNj4ZOjw 	 
    add_node mHm6caHHVI11uvX0061hS 	 
    	  
    		   
     
     
 
  	 item mp5lUOWnsMM2XxRPFLjkY 	 
 mXwfw45ts6GtpyDnORNut 	 
    	  
    		   
  
        else
             mMx9eMGCOFPe7QLaDuftz 	 
    	  
    		   
     
     nullptr mD0uYDf0yFcJIKmLr5xvB 	 
    	  
    		   
     
     
 

     mEOeUdjzJcqVbTxJEFkH2 	 
    	  
    		   
     

    size_t n_edges mmw3bRgOJHPUUjstT4PdO 	 
    	  
    in  mW9ZD1i4rYp6fFHKiPfVk 	 
    	  
    		   
     
     
 
  	 n_edges mEN5TkvYfqk1rTTUcoub2 	 
    	  
    		   
     
     
     ml1kouGUz2b40ANwvlarR 	 
    	  
    		   
     
 mJDqhxfoCmLYCFWsqAfx2 	 
    mbaGWRwadkIvpbYC8QrS5 	 
    	  
    	in mEAZQrItLUCDHrszPKSxF 	 
    	  
    		   
 
         mS96DCk7cGzjwc0qJTXyl 	 
    	  
    		   
     
 nullptr mVXbfI_6gsyimvB3bMDt6 	 
     mqi6C0GhTSi2iZGolaQ09 	 
    	  
    		   mFc8UPJY_sAkdHNDXdkof 	 
    	  
 size_t i muockitViZRRRXLdnikyY 	 
    	  
    		   
   0 mDkJRXDmc43cOr5nQ4LRN 	 
    	  
    		   
 i mIlcO7udeL3POKsM98xHY 	 
    	  
    		   
     
    n_edges mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     
   mtJZRp2pQXaL9Q_gd8jrR 	 
    	  
    		   
    i mENaUsQQS8MUXImic160m 	 
    	  
     mkLGZXWJUqSKVNKQrkV0u 	 
    	  
    		   
     
     
 
  
        std mmyVzy7lHCioBdbqbSEQb 	 
    	  
    		   
string u, v mVXbfI_6gsyimvB3bMDt6 	 
  
         mem4uNX6UWLQ4lH4i4iQF 	 
    	  
    		   
  weight mD0uYDf0yFcJIKmLr5xvB 	 
    	  
    		   
     
     
 
        in  mbcWZ8CkhRA4FSNYdPK5U 	 
    	  
    		    u  mmd9mhBKosF2vDtqHXRBR 	 
    	  
    		  v  mbcWZ8CkhRA4FSNYdPK5U 	  weight mAxjSk7V3Zt58gq8zwGDs 	 
    	  
    		  
         mmphymckKT9rpNOzXxLzZ 	 mfWGR95l9XIP6HLdGig7W 	 
    	  
    		   
    mlRrzo2zl7gRlogRGDp_J 	 
    	  
in mcIsboWLd94JhK_FiiUTB 	 
    	  
    		  
             mqUFdDUF4X6B5vcP8a3zB 	 
    	  
    		   nullptr mOgmOZFTxtreLwgASzn1M 	 
    	  
    		   
     
     
 

         mLmr5j32YSn8vyKJW8FU2 	 
    vertex_u  mezKB5J7MVzaJU4594iZa 	 
    	  
    		   
    graph m_GcI0iqNRmg2Ie3DCH0y 	 
    	  
    		   
  find mJDqhxfoCmLYCFWsqAfx2 	City mrZFiYMkFnUrPbLovsmm2 	 
    u mcIsboWLd94JhK_FiiUTB 	 mENaUsQQS8MUXImic160m 	 
    	  
     mI63IAdfMUkTvT4puK4tJ 	 
    	  
    		   
     
     
 

         ml1kouGUz2b40ANwvlarR 	 
     mHm6caHHVI11uvX0061hS 	 
    	  
    		   
     
     
 
  mbaGWRwadkIvpbYC8QrS5 	 
    	  
vertex_u mjPpyn7OlNhXSS1pxohJA 	 
    	  
    		   
     
     
 
  
            throw std mhnL1NgH2fBnYi7Kp6lmy 	 
    	  
    		 runtime_error mMLDxWypPk2AtC0udqL1R 	"\x57\x72\x6f\x6e\x67\x20\x67\x72\x61\x70\x68" mjPpyn7OlNhXSS1pxohJA 	 
    	  
   msTdVqp7Q2Ao6yvBnSmbd 	
         mLmr5j32YSn8vyKJW8FU2 	 
    	  
    		   
   vertex_v  mezKB5J7MVzaJU4594iZa 	 
    	  graph mkoHusT78U3npeo0P5HW2 	 
    	  
    		  find mkUi0Q077KNfre5zkr8F7 	 
 City mrZFiYMkFnUrPbLovsmm2 	 
    	  
    	v mAVWQSK8mUreY1rtWqvah 	 
 mg5AEJWy12t2Ti0EoNyA4 	 
    	  
    		   
     
      mmw3bRgOJHPUUjstT4PdO 	 
    	  
    		   
     
     
 
  	
         mp1BjjsmxFgRqeg53B7vl 	 
    	  mYatU86b1iLix9NupC4bY 	 
    	  
    		   
     
     
 
 mWwC_itzTcX4L_Ezpr0RC 	 
    	  
vertex_v meQxGCJFNOmzvGOLcV84K 	 
    	  
    
            throw std mXSJzCJfZauJGWjPpWFvG 	runtime_error mLb0wW_O4rnXC_UiwH7gL 	 
    	  
    		"\x57\x72\x6f\x6e\x67\x20\x67\x72\x61\x70\x68" mAVWQSK8mUreY1rtWqvah 	 
    	  
    		   
     
     
 
  mDkJRXDmc43cOr5nQ4LRN 	
        graph mMf15SofMskq_UHdCGcgB 	 
set_weight mYatU86b1iLix9NupC4bY 	 
    vertex_u, vertex_v , weight mcIsboWLd94JhK_FiiUTB 	 
    	  
    		  msTdVqp7Q2Ao6yvBnSmbd 	 
         mSIKCWWwblJBQMXXFrGNu 	 mfWGR95l9XIP6HLdGig7W 	 
    	  
   mlvuCWtduv2Xl0DQE1tX2 	 
    	  
    		 is_directed mcIsboWLd94JhK_FiiUTB 	 
    	  
    		   
   
            graph m_GcI0iqNRmg2Ie3DCH0y 	 set_weight mrZFiYMkFnUrPbLovsmm2 	 
    	  
vertex_v, vertex_u, weight mg5AEJWy12t2Ti0EoNyA4 	 
    	  
    		    mmw3bRgOJHPUUjstT4PdO 	 
    	  
    		   
     
     
 

     mMTaoT0bnF8UlKG7aMzat 	

     mMx9eMGCOFPe7QLaDuftz 	 
    	  
    		   
     
     
 
  graph mI63IAdfMUkTvT4puK4tJ 	 
    	  

 mEOeUdjzJcqVbTxJEFkH2 	 
    	  


#ifdef _16940363544217905432
#undef  mSIKCWWwblJBQMXXFrGNu 
#undef  mrwZbkiUhvMainRLAdaF4 
#undef  mxw1dVQpcJUYwXr_YS3Hu 
#undef  mqUFdDUF4X6B5vcP8a3zB 
#undef  mBTjV6EU_AfTO3uKoc9Gv 
#undef  mgELUP8O1EUeURhKNay2M 
#undef  mc8FuavdSiafUQiqBlxj3 
#undef  mOIhzPwnoFgztUPxlDIYi 
#undef  mbfnvAlhjolu7fj8mhL7W 
#undef  mmQG1JqJOFL4tSJ8iPofc 
#undef  mSXgOgxGtwFQV6AKgVHq4 
#undef  mXqFHR3sSfwwevPh5ymTO 
#undef  mIqygiXrUxkDdM7ZK1MiA 
#undef mzzSk275DGTWBRbyb9rowFyxxE0syg6
#undef  mhOXUHjosI81tibbjtY2R 
#undef  mcmEKrrIh46a46R1L5eJV 
#undef  mWTiqLSwe0xTiXrCL5pI7 
#undef  mAtVXIDpppH5G38sGX_Ll 
#undef mIyEIwqU_iab3I3CfzKrImsbTxtjGVQ
#undef mh0Oc5r132Q34V4corcQfi2gYydDIag
#undef  mE0gZJUZ7uGHA81Ne90c0 
#undef  mMotrlzgDU8amwkoQJ6Ry 
#undef mbEBra41Z6m7E9SquGHRv4V6T1XVHVI
#undef  mBcAeUOI_3W6sRf9OQEjT 
#undef  meGAP6SwYdNLaBoUOkzJ5 
#undef  mMLDxWypPk2AtC0udqL1R 
#undef  mI63IAdfMUkTvT4puK4tJ 
#undef  mmyVzy7lHCioBdbqbSEQb 
#undef mr2RSuF2JUZbYC1SOD8VeD4zccvQvOf
#undef mWF0DImoReIPT7QxRwn08ghoQdh9p0e
#undef  m_khVq9GCCuM0DdfVhNUS 
#undef  mXkKTJAXmhsypa4doa0d5 
#undef  mcMWdTIw9hykZ6Pk5U6A6 
#undef  meoN4He9iuQSjKcLsI5D1 
#undef  m_AWKOg0joh79CqaKNDD8 
#undef  mEseQ3V22oLNqxXdZPHSp 
#undef  mp_wKWA9lW3GCbwI4kWqy 
#undef  mwEJzZ5ZhMUs3fB88u2I0 
#undef  ma1ho7taMKdaAhSuZBmRv 
#undef  mLUeTlnJbSdKwtHMEfaEW 
#undef  mk4nPDX3OWVj6aF8GP_6s 
#undef  mSb2hlXrDdsA4X9LdJsZH 
#undef  mFM3eDZ6mDf4XDDnyjydm 
#undef  mzMnBoR9EbBxFsNHquKnd 
#undef  mNioEGqrE4NxAg4aq4Iul 
#undef  mRlyipJtwk85jfZptNUSu 
#undef  mmw3bRgOJHPUUjstT4PdO 
#undef  mcIsboWLd94JhK_FiiUTB 
#undef  mHm6caHHVI11uvX0061hS 
#undef mmVDmhGAU7_zUprLvEKZE3bpkiNVlBE
#undef  mkwk_SfTE26Vti3_TQx2d 
#undef  mg9OLRlDobrwc0sBiggQP 
#undef  m_GcI0iqNRmg2Ie3DCH0y 
#undef  mzKpfFBMHE2NP6rBG4jDa 
#undef  mJ25Y48NFsuRDG6LPWxko 
#undef  mOWafrPmaCi4YWGk1gOIE 
#undef  m_vFio3KGhiXF3_fsdTur 
#undef  mXwsoUNqIEXecsYUwicfT 
#undef mNrPIbC98utP6wBfT1KbyoqdsjfBrb_
#undef  mQRi5yf2deHs9gSEi_MdX 
#undef  mh4HeOu859_uMglfGQuUV 
#undef  mUpuVXB3KaIN4OmtaG6P3 
#undef mf41jBZlYf6B7HVrlkVoT81pEw7KfE8
#undef  mV22exJvekssCg6yl44oX 
#undef  mLOEzhTERjG6qQ2C6OZhc 
#undef  meZ6JRKjgwy53PUyoGkP1 
#undef  myCH_K4LEWewm1b60rHu1 
#undef  mNh9pumM2BNjPUmJsVAS_ 
#undef mEKXn4x_XE7ojNBrDMcHXt6RhiW3vAc
#undef  mB2EkR4ytt8GIuNHPzTQt 
#undef  mrZFiYMkFnUrPbLovsmm2 
#undef  mwyTItdXt9roBzyTe_SB1 
#undef  m_kPZnWSMov1u5_Gshi_3 
#undef  mZAr23O2Cc_FJLBlsQk7i 
#undef  mqxpo3VXi6s5WZz_sFPzx 
#undef  mXd6vxqyUH9LlTxcupScb 
#undef  mOc18vNapbiL3Cb12rAlX 
#undef  mS96DCk7cGzjwc0qJTXyl 
#undef mm5mUeOPKEPBbSyE7p38BL2P3um8XtK
#undef  mk0GBQVNGVh1otTd0PP0R 
#undef  ms5xkpevYj9kZADBgaJVv 
#undef  mFSuHk43UETede20pTw1Y 
#undef  moAn39dtB26Af8Crh4Dok 
#undef  maaVlQv0Al7zi4tOJEYTP 
#undef  mFflUmA90Nwq1sytCgIRu 
#undef  mIlcO7udeL3POKsM98xHY 
#undef  mbFqZkCNZprnJV7Uc0FsR 
#undef  mh51oGkTvBtVDO9uBLxzx 
#undef  mvdjj4pAkOckwVPfXCeO4 
#undef mECSUTiMDNfd8lQJsFXbj7pfsGwXi7x
#undef  mEU3Nfnc5zaZ6Srog0lkY 
#undef  mebKQmUqdvuwTrUAkuvnD 
#undef  mK3bmiQVZHz1efWBNYej5 
#undef  mE72gOTGkQKdHj35mJWgp 
#undef  mMx9eMGCOFPe7QLaDuftz 
#undef  mUTcbpMJ4KNDOqG9nLwSI 
#undef  mD0uYDf0yFcJIKmLr5xvB 
#undef mGKkTxokgm1WDfckGlgo1O2YX56YWp_
#undef  mbfTR7N9k0bIYb32x2Bmc 
#undef mEiIHpigjbQmdOIMcjUGXugpTJNS8tM
#undef  mEq8rBq8i0sqNfR8kfCyT 
#undef  mRzOeC7ET45Is0MQkHWcU 
#undef  mKhUQ157RCVZPn9jX7e8m 
#undef  mbhlaDX17iNZwUGceyEmv 
#undef  mCEkMCVrcWGoqymDtZ_8D 
#undef  mvrwa90KhpGAnhz68cgBm 
#undef  mS81lQyCdOFGhOrX8TcJj 
#undef  mrZxq8nuRhd7tYq8ijdbL 
#undef  mDAWwvcgq058ilVrpKq61 
#undef  my2pE0O45B5cAJ8E8g09e 
#undef  mwxEDs25A5j27b4aBHJDS 
#undef  mBhPhpL40uN1zY9o48wB9 
#undef  mAeEvEXGRlOXQNMwGFhRz 
#undef  mqEwYWkQsX18VNmsFRGbG 
#undef mcu1VoSt5SkC1e4eYyyzVvbR9wgtNSg
#undef  meQX_EQeYK89cHOlmkF44 
#undef  myULB7Bpc6er2KRGa6xBo 
#undef  mF28w7kP6PpBmcslyhQ61 
#undef  mBNesC8Hm5JVG0ho07wnD 
#undef  mtMapsiHV10H4o8O2DLQk 
#undef  mkLGZXWJUqSKVNKQrkV0u 
#undef  mlRrzo2zl7gRlogRGDp_J 
#undef  myqmXuOf4B7g6oon5kVLk 
#undef  mCk_UIbrTCUhaCkMu16cg 
#undef  mpbJOqPjEIaMOMX9rHfst 
#undef  mLRhw0OpZPF0mqyMtCiP0 
#undef  mnr1FABr1GQAkEWe0GQ4Z 
#undef  mJaftH9P72dfWyyuFeXeF 
#undef  mvnG1o0mALo2ONGXV1qtj 
#undef mZ5bk68JO9_1OU7SG24hzbQEFTm4W7p
#undef mbpytHgdMpZnGVeVkZCwmmhzrszM1gp
#undef  mNVavGzw1XjMhvmKS4Nqx 
#undef  mMQxB7jpjfOui841NPs3M 
#undef moEFasgxw21aqoLlm3lbgNgjFZdkxfd
#undef  mTjUlYJ5OO5DOMyXRQsic 
#undef  muockitViZRRRXLdnikyY 
#undef  mitexB5_WiQ7RWODruVq2 
#undef  mTLB3DThkuMojfXGOuOqd 
#undef mm7WqRINy_suu8NcRb68YO3PO16MkS6
#undef  mA1LGKQ2vMEJeTW7wKHBd 
#undef  mBX5Lx6G35mEnI2ifH8MP 
#undef  mJoW7HwZwilvORDSuOnak 
#undef mORoFiGpZBg3Zt6XtjKsR4zvdhIosAi
#undef  mrzCzQz58BXdd7jAYQS3D 
#undef  mnrpPfDjnffp5G7So8iDT 
#undef  mOegwFkLE5WcMWfpapSiS 
#undef  mcrRKXEKrw6iwUUiFgYrz 
#undef  mvibfk7RK7iUxu1iJrSUG 
#undef  meQxGCJFNOmzvGOLcV84K 
#undef mKKl0rRSwkHzF_cQyrmzTvv_ULobOhT
#undef  mVuUY4D6IFeRzkw0r6FZD 
#undef  mX33Z_oe4c9GUmpNiDYPE 
#undef  mNyntUbOsBRcoNgiwVWts 
#undef  mJRVda6nnbo8Ap_WJnU0S 
#undef  mKwsI2KPDPh53SKfbjrLF 
#undef  myLxqmTL1E_nkiRE1rM3z 
#undef  mcmUOACchas4y8FwTbPNo 
#undef  mqIB38fjaArFQU48PgEEm 
#undef  mgNXkJ3w2pmEsY0Zq4TXK 
#undef mtjpOs30tkubrkpIbkD3qP8rvE7OAmf
#undef  mVLhP7JW8X7cOcs9brY2M 
#undef  moRbSYlVEL5Oh7hKNIiqi 
#undef  mKtdtMAUeS4wNjuOg8XI8 
#undef  mS5YyMzbYUGXm9iU17uaJ 
#undef mh93ddSXQl8tV77CtCpCyTRaxYmk_hQ
#undef mdQQkM9igi2sYAUtXjokf7uj20yTdUo
#undef  mA1hv1OJBo1FNqtVG4QGH 
#undef  mCkMUSHBm7GTuAYRsIhRF 
#undef  mzn5gQbfEW4L4DLj545sZ 
#undef  mdIhNqRMvupNM1BjwjLq3 
#undef  mMGtMp_Gj0E7GVLCK4Rkx 
#undef  mtn1bxwVxZg9rr3PCi_mh 
#undef  mOKcEjwIIgirm1vS6mwT_ 
#undef muNh6D2Tafwwv3rQdcYWbaElkme64y0
#undef  mqi6C0GhTSi2iZGolaQ09 
#undef  mYYIADTxl3KKynU0mFm4r 
#undef  mLxRGVua8tXocCdE6Q8lX 
#undef mC4DkCZDzZrRAauoiTt391X4hEA3eHC
#undef  mVhBXpHpgyJOjdfVzCca7 
#undef mWLLg4Iksf30qdjaLjDSf0nJZwQCvA1
#undef  mgaUL2SfhwMyQIBMlr9PO 
#undef  mM_dTRuxNP5stA4GQfBXe 
#undef  mpW2qwJz7VOO5c6Zm03SU 
#undef  mMqqPQHXPR2eRRsRWKEX_ 
#undef  mCgp0NjWsaMT_gvFB7h7X 
#undef  mitLWlz39er_0tHsl1Gh_ 
#undef  mEtdYYLeLNTI6S4cVKxKg 
#undef  mVXbfI_6gsyimvB3bMDt6 
#undef mSyHpt_Gd6HQsC_XdYk8MSOjvxSqd_l
#undef  mPZ5N1uC5sRKnTX6is3TA 
#undef  mfNnjNax9foXprf7oIzMk 
#undef  mjxwGXBtofKTW12YHgaqi 
#undef  mEN5TkvYfqk1rTTUcoub2 
#undef mIbUmQSAQIaYVq08Ujrwa1jjDoCT1LR
#undef  mOR1ORLGvLsygR7Q4RhbT 
#undef  mFnDEYAyWoistYgpLmhnK 
#undef mOwoVPAiW58KIwMW13pncFj_lsByLJg
#undef  mJLsjlFTZ1IMwtcwZ_6SV 
#undef  mvbs8E2fQFh4uZpCBj6FP 
#undef  mMbQosASgXxZZoG_aTlah 
#undef mi2gRrwc3jS0Rc2cSbVpE6sJgEKPZBM
#undef  mqXkAgsT1faNewCqkytZ_ 
#undef  mL_IWLwoCV5Ep0j2eD0cr 
#undef mIbLcLHwZD_6N_7Dul2Rk0wsrQpjcMT
#undef mKEZAO1aSc03CpaP96FIiloKjpv_oSW
#undef  mRwoRtnXonXm79shoecyZ 
#undef mXsb8PGB73xCrvowfZdRPCRwu7NCTev
#undef  mqxaUvJOqbciuU85IqQB4 
#undef  mS2FcN8xCd0Ha4nIBWUA0 
#undef mtr98ClmaM6Xxz646N9XxhSyEiyxEer
#undef  mhzBg98kINeBYt4gbLQPV 
#undef  mpQtzhcgp6s7bZ7_YF5tb 
#undef  mCyo0RDVApINz1pBTfccH 
#undef mWfNZwTxDEVDeYyvuJtnVGdes6EXLe6
#undef  mkmdQSmhZ89xOqIgp_Lio 
#undef  mohyp7pXcpRWNCAtj1Hyr 
#undef  mZyn1iNVbpPHdDlryThCz 
#undef  mf6d2mblZCL0bDnhZ2l7r 
#undef  mWCos3tx0svmm9caNwTyW 
#undef  mmphymckKT9rpNOzXxLzZ 
#undef  mUSofcgwFWp2KTpDrIZhT 
#undef  mqH2u99gVesesneIBlk9P 
#undef  mLTWKMYngrJ1kghRNloor 
#undef mZIb4bv53F0mCUiuS0F_LtgLp35nUpr
#undef  mK_G_gmg1E6Wnit7BoGR4 
#undef  mA9NqCZTzzmkoYPnVYf85 
#undef  mFDOPIZplNKGusGebDz0d 
#undef  mffX4Mb062PgLzQv1TIKW 
#undef  mzcgloebGZH_r2TJF0dtn 
#undef  mLhFW_jVoQ7ZmP4xNj14g 
#undef  mvYtFZr2O0LYS_Bj7kxQR 
#undef  mfWGR95l9XIP6HLdGig7W 
#undef  moqlLJiYwJfWNOQWDa28i 
#undef mAeuslGyrBzZATxd7NC7hbC6uViO4vE
#undef  mNVpSDPeuIaDb4_NnIiJZ 
#undef  mwooVFmjsEVsVTbGXxAOW 
#undef  moenEd9QDkXM71zbIvj0r 
#undef muatRTgz9o8VnN3mgwXYVxmJekenWeE
#undef  mq_uKqniIDapQBuAIsE00 
#undef  mN2IvGU2ycYxUO3z5pSXU 
#undef  mEMu8fFPN555lACTguL0l 
#undef  mjTk309njdOySslpKbhQ7 
#undef mT2VlwIn5WIPY6C3Ox6k5radH5CkIgb
#undef  mtNHqZ2b5x_L50LcmM5h5 
#undef  myuCe0T1_Yujw0HVZaJGc 
#undef mmpGZRMT9NY6ZF5mzATENhaNVA5NWmh
#undef  mPGRULb4_lqnmjatIaJFD 
#undef  mWm4aOyPpazdfQtWi9ZDQ 
#undef  mtBIlsbirBWdyHza6uu2y 
#undef mx7Nyu3yUhJbKHO9e4ED2OJTzN2UmZv
#undef  mIQmjme0qq2SMrI7RlM2e 
#undef  mYw907DQHy_p7w2eV_txA 
#undef  mqpurlNYzM7gnGcjNk20A 
#undef mwxhS_LnWY8GfTId2nTqnUOxwrRF9oJ
#undef  mAxjSk7V3Zt58gq8zwGDs 
#undef mE1Kcrd5_vUp6imXcoS0Vwnc4_qbodb
#undef  mMz2rd0_FlZu2fwX3BsGh 
#undef  mimHYvRuv3ZpkVpdX_quP 
#undef  mhsefSIcf4V6S1nHJs6Yj 
#undef  mdYUXXHzUJWD2QmPpJ1FT 
#undef  mS9JbQ7MfPQUUmmv3_DTr 
#undef mPw5wEccOUGwAYHltNHXzvFgCvzrhWe
#undef mVwJKRF0f8m_9KEfD9lorHSEA9KwePG
#undef  mYW3VPUS2jw4Ls7HaLwjA 
#undef mi3JDhzLGNikjYLKc7MexY_OzbIBcgJ
#undef  mBalqudrUYV89wC2Yma_H 
#undef  moghvkiDGJkRqfvQE0j0l 
#undef  mnuMTIVPfOMqTWSYwwOqN 
#undef mC1dG3DGorgEYGAZdn0aEZxmogNNMsS
#undef mDtgT0KdCnhW28807Ed97B1GelAKzLG
#undef  mF3oZFtwnYWCjh2t66x_y 
#undef  moSRhtXgXx4U88t5o8Pef 
#undef  mdNCwoIt7K9hz53B3X5JM 
#undef  mTYL9tTJqlqfhKn4BBrbc 
#undef  mgFyCMiVrOKN5tzswUUwo 
#undef  mQ3MIzag9dRY8gUzM8NUC 
#undef mb550ZfzLTevizLKBMChp93U0uX07Wi
#undef  mg0BYO_sPDJ9XLWAlYE0Y 
#undef mXS5XuoyPFlAQMKb544ofPQe28_65jx
#undef  ms5ttcSN1nSlQfSlc60Ed 
#undef  mIQ9B36L6YiDxtw1gO9Ri 
#undef mZEzzifzuRXYqH5fl3KY3ucZJskpDE6
#undef  mNyy4ILdEM_B2X3Tihj9l 
#undef  mPpWIR5WO78gKdtnnbt33 
#undef  mA9SAyDkPEu_jezHMTuD7 
#undef  mo9fl2PoH6mxlwnG3ZkkH 
#undef  mYatU86b1iLix9NupC4bY 
#undef  mMRhDG9maBYbskETiAPKq 
#undef mmOuGGoEmeHG34dT8HuARGn6HuZd4Yr
#undef  ma60HC5RIzC_0KauYf4l6 
#undef  mLTXtkErtbhuf3CR7zgQN 
#undef  mtFiumm5c3nAucnufZQhp 
#undef  mc78xS09AQ8sPJ5QyaLvd 
#undef  mxptYoke1HsFECfC3C_r7 
#undef  mgry8VlJBf2gTZcJT1KeS 
#undef  mK6959Yv6ZVwNSByWDkmq 
#undef  mRiMyTYG0EHoU_AfW_I0E 
#undef  mfTwWG0EnM_PZsxYbOBae 
#undef  mIPo7Kt5ZKwUyqbJs0Zuf 
#undef mRKQ26F0H_jhB5V9_5evTLxYKRLQAcc
#undef  mjHMlqhASe0yLr0M6UQA0 
#undef  mF0R93EXj46LAmPI2QOy1 
#undef  mKIrSBqhMuE8eXMU4YZ99 
#undef  mdokE1oQ1eWvJQBOB_y6g 
#undef  ms_li9K6cOLGcAwQKrWWe 
#undef  mGRVoGDprHVRAah1QIP9H 
#undef  mxD03htSURAMcvC2fuOXt 
#undef  mjAHhTVqiwaiwwh3Bf6a3 
#undef  mJlKFsXC36dnxnFP_ktuJ 
#undef  mni7jglQszhvOvUr861rI 
#undef  mwyRWATNVVL53iFHwKfgW 
#undef  mxsKm7CRqCWRxmSnteLwV 
#undef  mhmHrGpRLKtig7irTPYx3 
#undef  mvnfgjYSTZxrtqShKnIUs 
#undef mZZnYphSlUD_OeADVSXF5WozHhjWVet
#undef  mGSG390TQKr3aw8YMOeys 
#undef  mROc5XOluWHYOoUQrFRoA 
#undef  mWLb3ZQM78olb_pGmdqLW 
#undef mdTUI6HFwhKq8Bc7EZsHgLNbYCfEdOU
#undef  mq6pHLmNL8McGUwhTWstE 
#undef  mceNb45KoJSdU5Df_8ckb 
#undef  mLjRF_VniD2bNv1P8vOtz 
#undef  mnMRTAIUkGa3FHhDrbzJK 
#undef  mfMfq4bjVUlfD1YgmvFuw 
#undef  mqFmT0F_gM5x0oqAgmvgn 
#undef  mco0zAFcjV6xFzcR2x8yW 
#undef  mxz5jTMcHIbWjtvVVOcUl 
#undef  mhIB3qNZfUmw9QkHix8Os 
#undef mIL9mqpEKWG1YPz6Ncid2UCNAU2LA5I
#undef  mcHA2b4mauE8r4RuNr5nW 
#undef  mdd4jrJYcIOPWh0PhqcHF 
#undef  myClXrwoTaygjs1btdmSY 
#undef  miJnSg2V5jJi6Kn3hSEQx 
#undef mDKVmNWOqx3txfwmTrTP4qA0DUvxlBh
#undef  mg221aN2v5D33af4AflPI 
#undef  mvwWkYX1zaZB6iEe9wd2_ 
#undef  mno7O21OT7TtMoAsHfYRf 
#undef  maPcRX0qklJFkQhvTAgXk 
#undef mC4Htf_gx6VQNzhVr0P78P3sqWuBt8D
#undef  myDQweaUOQFzCCXenAhuk 
#undef  msOd9t5xjc0wEjd6tEMej 
#undef mYWCjiV142KGvEz_mug3lgmxTvCkGWm
#undef  mUg43TnniMvHgWj_bmJ4x 
#undef  mbcWZ8CkhRA4FSNYdPK5U 
#undef  mmoVCw9MByHluMInTSr5H 
#undef  mUGztzNLL5VzgIrRG7BCP 
#undef  mPP83Lg2R6WHKyIfk7rVW 
#undef mH9awoXOCiHjLOD9iTnV2zJU6wY6LlP
#undef  mFkHhlfVGAV7dK0wjdFyG 
#undef  my4qInuPCPePmx4YoVPb4 
#undef  mSqxm4jKzW7JHElhjeuHM 
#undef  mp5JdntgW0WaO0DSkkiD7 
#undef  mRcsq2_d_RbMsdYfURxCC 
#undef  mvmZyeTS6QFgJSLrUaJ1m 
#undef  muWe2naNSGtkTuZ6CRRoX 
#undef  mH8GbV_SeQqnS3gdyxIn8 
#undef  mjmXJT9sMAkxKt4Bwt1cC 
#undef  mvv7b6W7jDEnJWHll7c_s 
#undef  myF8OiAVbmpoDNw_Zs3p0 
#undef  mjPpyn7OlNhXSS1pxohJA 
#undef  mpI6ZnmT6lESTINJBdr6Y 
#undef  mdDMMmIbhUyR9NWm669z1 
#undef  mQJjTsfNEVkxgGUTxLeVh 
#undef mM8ko9w0AUekhlsZVjUDnb1Vf8ixBzs
#undef  mxeYyYHboDq9jd5vBF0VJ 
#undef  mMA0zWl2Vxl3J9wImhh_b 
#undef  moF97YFwuRaYk7g4dysDp 
#undef mj2y6knl0gVFKGGKgCJ8ON8vwFQTYFy
#undef  mY8r7uMwZLiW7F67xaZe6 
#undef  mW9ZD1i4rYp6fFHKiPfVk 
#undef  mI1fi6VaA4xADpjYSLc0x 
#undef msofBRtVBuSTG9x92JyKUFq9wXwetdF
#undef  mVtWZsiaqV_rjM_jgAl4G 
#undef  mSFyHqUcmnJ8Vclj35RVG 
#undef  mEOeUdjzJcqVbTxJEFkH2 
#undef  md7kBHFgb5g8IUSqsawo1 
#undef  mUMeNwogF18s0Rk8BN1ef 
#undef mCAWMzcwxPqupX2w8MXk1W47ueMIryP
#undef  mJarSpgcnO1gVxH6HkAgx 
#undef  mop6YtICyrG56yH8dACU0 
#undef  mlO57mT7ExUvHewmZNgJL 
#undef  mPvqzMiH28W5M_ClWng0o 
#undef  mFfoS3HnMnWkHYjXynUR0 
#undef  mnELdn7MgX8eBkBTITwX7 
#undef  mIl6hC5HWztlAxWdSE80F 
#undef  mw9Ub9rz1vMsGbOLeUhFt 
#undef mW2s0v5Pdk5UH85dXvdbAcPztw1wKcX
#undef  mYcXHOdMXaO9azHyYOYX4 
#undef  mdhYJh4kkKeHSDCsRFls8 
#undef  mP8zmXl2F2cZoHrFGrkzq 
#undef  mo0Vk7B9urnQYQWqdPhkd 
#undef  mz1P36Gy5NX5xjXaS7z9X 
#undef mFF5Fb3hKgaSHkADjP87gBecwNacc9I
#undef  mFcZEli8o07ZtflsqeSeN 
#undef  mFsBRUBWTwZOy_dZvzGA5 
#undef  mwXmm1yhrVhmhUECcWAR0 
#undef  meiwg2qg7SN6VCsVORgmD 
#undef mjZpgStCOvNdOAxhhXE44CHW3TLV1Ct
#undef mAolsLWZt8dW36eretJ3EHIemkurpUt
#undef  mv1AH1VRP0cpdKqJi4XRA 
#undef  mlvuCWtduv2Xl0DQE1tX2 
#undef  mRLJEWBGSkWNeFP3I9Q0J 
#undef  mvEQa1EBvsvhwWuInnGH3 
#undef  myTTxAX2GQaYtNQVKE7J7 
#undef  mFWkynJ3kVqxFHdG8sshL 
#undef  mXSJzCJfZauJGWjPpWFvG 
#undef  mxdvKgTspdDuYmPU5oKiO 
#undef  myc1eiJMt_JopcgqPfl09 
#undef mmupizzDujaSejSpjxntN2Ni33FUqXD
#undef  mLAs6ynQjxHWuXPE5MQvr 
#undef  mYG5I2m_3L34kMvHPVMKV 
#undef  mALu64soUyrnVdbK5oLDg 
#undef  mRKgyXvTMLZoi7oCjESC_ 
#undef  mprQ1kbLhaIOB0CjwuSu3 
#undef  ml_XDMCMsVT7qVLtQxfEV 
#undef  meHwSukAeikQ6p0ZQA8th 
#undef  mX1Uce0EdHYrUmfpk_c3g 
#undef ms5eYctUiBUQqEsVGbqfnOvlAOFg9qK
#undef  mRN9LVdYy_eTrJB3Qqx_c 
#undef  mmGK8VQXf93HGh3RYUHle 
#undef  md5n23JPcpUWeV739kfAp 
#undef mFTl0dnUyEhHFzCdZhLIQZ_rZQNyQF3
#undef  muxyB7Z0gbL1wH3QSFUqK 
#undef  mQyLvM2lxKzfyjQlZ_jgQ 
#undef mqQb9HRJ27HGUJ5toqoRj06W2O9kTUi
#undef  mvHU6_7N7UloE30MN1UVL 
#undef  mJptZLCKpBlOifAJwRCS4 
#undef  mktIEAnORIRmVJxkcDivy 
#undef  mAVWQSK8mUreY1rtWqvah 
#undef mfHevy5L4CnVY7y5zznyn_apqQ10PqN
#undef mapwKpGpUr6qGsfRGclReoCdSuMuM7X
#undef  mpCU8770rTaXnMtB_o9Yu 
#undef  mITk4pDtCxCgqNW6rty8Z 
#undef  maVZ9zHIOa8SUMlvfjL8p 
#undef  mMf15SofMskq_UHdCGcgB 
#undef  mYpKpgbNyqc0hJijg4DPt 
#undef  mJwHJZnUBBX5NuCixyUdg 
#undef  mctqRtJqoKTLnihVzzfzE 
#undef  mqEQCH8H0YX8Ghpz07vz_ 
#undef  mtx49egT25xfhnSdYFW6k 
#undef  mzQAyy57LdShZFhIbDuOd 
#undef  mbRHDqa2M4itd9dDoXwnp 
#undef  mLKWwk3H_ZF6dtVJGOZTD 
#undef  mjTFD1tdKx6_AR351Y8hx 
#undef  mdj7HUDaC7EVdgXeEUF7n 
#undef  mGgzObSaFyKuFDcxosJ2f 
#undef  mgtvXj6JhpLPDCXWXDqUG 
#undef  mymLxVhLQGYaSNjB_qUxi 
#undef  mzM9PiEt8QufftY01nwkk 
#undef  mdCHaJk_vcec5Oe5WQn9p 
#undef  mXwfw45ts6GtpyDnORNut 
#undef  mPtRBIgD_gzRrQT0MqXXz 
#undef  mRTIWhPBiZqVOgDIS_qjc 
#undef  mmb9i1ayWQG4b5NXRjhUd 
#undef mFReoTHJt1YvVHhwd61tCkhy6j_DI_C
#undef  mELJEgyjwpoPaT0WZVOL6 
#undef  msTdVqp7Q2Ao6yvBnSmbd 
#undef  mOgmOZFTxtreLwgASzn1M 
#undef  mRguxlapp40Hv1_0B__mP 
#undef  mRcA3ijPhJGTkU4gCoZaP 
#undef  mp5lUOWnsMM2XxRPFLjkY 
#undef  mkoHusT78U3npeo0P5HW2 
#undef  ma1Jz6AETpwxpJwfCXDC1 
#undef  mH4foEMMXqFUpMeqVhRW6 
#undef  mUWOU5eAgUrmg5YiPTNkB 
#undef  mU1wDqXg5xFOcdtcKEgzu 
#undef  mMobspCJYn07bG9id4QEy 
#undef  mcHBL5ojnWNEcge6ywHbK 
#undef mYE9yO4TAw8QwPe6FpeVu5f9RgsLqfN
#undef  mWCUpPLiv9jUan3iLQvaC 
#undef  mAG23IfGHF5_EASIC8GSm 
#undef  mOtAfA05M4eCiXVMzOBcc 
#undef meHkZ7MGj0a_W5Otlu92YfiIODBhvcX
#undef  mq_5K9XylAGsUxWxgqkQP 
#undef  mLb0wW_O4rnXC_UiwH7gL 
#undef  mhApwj0qMuqc1Li3c8CmS 
#undef  mBsaMK_4KH9SFDycwwg7E 
#undef  mg5AEJWy12t2Ti0EoNyA4 
#undef mxImYbjSVFmpGv9GdVMg2HsJ9of29Ti
#undef  mlg4qFrHjJMgqH1jvkHxq 
#undef  mpo0m_VTbg2HWHQNhHYAl 
#undef  mwiWyfNBaTeR3_Zm5Kiwe 
#undef meKKzaczwcTR9YxV9etUDUMlGdBAFRv
#undef  mShkdyn3Mm5RRQSuIn1hx 
#undef  msmdRo5SPgR_scMNFfZfB 
#undef  mAGWUsKFjs2dIhVNF2Rio 
#undef  mGd5xjt58XlyBQlgqjsrT 
#undef mRjcszkkV5lsmDfZ0dPlnUE06VzfZH3
#undef  mqW3zGO4xVFxmJFn5GpQI 
#undef  moATWv2ubKDLSjiWSnqV3 
#undef  mtJZRp2pQXaL9Q_gd8jrR 
#undef  mSTC3WsWlJSI37ffUBL9j 
#undef  mRP2JugK7WlfDrXDy51M0 
#undef  mhWT3pw8Dm3irVTor0bz7 
#undef  myKOqKTXsGjDoHOCt3wYF 
#undef  mDkJRXDmc43cOr5nQ4LRN 
#undef  muj1v828UUr4wE_6f9Fox 
#undef  mLihFCfYEue35T79r8NR7 
#undef  mbaGWRwadkIvpbYC8QrS5 
#undef  muYvrI3hJ48NC2YSop5_D 
#undef  ml1kouGUz2b40ANwvlarR 
#undef  mVdfuMlX_FwassQtBJcZM 
#undef  mWwC_itzTcX4L_Ezpr0RC 
#undef mThEh5ms1BKQ8bN70ogqfPhFaya1vv6
#undef  mmd9mhBKosF2vDtqHXRBR 
#undef  mKzFCioAQSct67CTXc6VR 
#undef  mOhG2JOxxRwIFqO2pOhpZ 
#undef  mto_TfB9yb3WhQTVQWibo 
#undef  mHd5Jm2uJh_0QXfGtzP76 
#undef  mLLWxRP8B9huD7dcj5KvO 
#undef  mOKKRQ8kNVU1TBZE4Witt 
#undef  mzYL1GEmWAaBe8cZDUp6E 
#undef  mnHm3VU3s7bS1X6gk7p0o 
#undef  mQ9oBnYJc4rpK6G5vBmla 
#undef  mTFfBW48_T2cEA1Q9Ymsl 
#undef  mX6C0A8nKROY4Y6Fp9ykR 
#undef  mYG_O4HqcFbOirQkJXnOG 
#undef  mKjOQtSyzlLLP2WCFjxJA 
#undef  myhPlHlhkjCSnKEWItqw0 
#undef  mlqMVh4Wz0NrFOdK4oZyB 
#undef mHV59MtjU3UcjrEryXu9Nne_7OyOoyR
#undef  mNymIbFkYQv7FBzyEzrOm 
#undef  mbDMCsyKbnmASUeayPoTk 
#undef  mVV9wJD2EPC4NlYxtFx6S 
#undef  mezKB5J7MVzaJU4594iZa 
#undef  mqC_STYnPIwnXtDVyoZ45 
#undef  mJ6oeX2gQZh9wk0CEVrQ5 
#undef  mATKxA3c2JxCQOvaqlrXo 
#undef mDcfVgzMxUrlYDdqjkIdDMllHO8_fkz
#undef  ma0QGdwNgH6IdhnT6DxDZ 
#undef  mF6JvzA91gBX6rzd4Va26 
#undef  mdgH93XqeC16RIGBU8U62 
#undef  mb81M5ZIRWsZ82CFlcGzr 
#undef  mSo_OTUYqcFyRngKq1oQj 
#undef  msoHPcGVX1hkDmWfyimbc 
#undef mp01MDDw6h6CqS9v20ElI5u6CnZdowu
#undef  mhnL1NgH2fBnYi7Kp6lmy 
#undef  mHVbn6ACOb_IwZHa3byDY 
#undef mb5bNRXIcz8oEnvvpWrdkdrvWu3O5f5
#undef  mnRPHdQ3nzy3LpT1IuT_d 
#undef  m_Qir6dpaHV8CVR7xPBYK 
#undef  mIlh8LdY76IpcgyeYbzHJ 
#undef  mDogQWyFxSX4OobfyB2TL 
#undef  mYOQr0clNFuO2oDoBnlWt 
#undef  maCz7cocsirqHN6Az39Ev 
#undef  mO9qmAra7ZIPgCOt7mLUA 
#undef  mqQMRoY9oIqQHFBpwJlBt 
#undef  mKEDQsTqmyLGA6mjDCcmR 
#undef mteRmEralkYN_0LdwNuu6xMpR3_14DE
#undef  mTu0ZVuAFMjXctNj4ZOjw 
#undef  mZcuu8KI02vjnupUAvrZ0 
#undef  mlc8cSWyrn89xf_lN1nYp 
#undef  mGfzt9CUCLAzxfdWmRwAN 
#undef  mrDw5DFAsZejNlsl5ddWO 
#undef  mp1BjjsmxFgRqeg53B7vl 
#undef  mgG56konUwY1GdiIPcKx2 
#undef  muqXNalaAW0J4iF26vbIS 
#undef  mVjNYWyMyfnTnz_76JrgU 
#undef  mTziAGzapTml2cv9WWJq_ 
#undef  mZcXvwouXhi132jqPNQFA 
#undef mLmD46ivziM1mihdFp5LhQgnmJygt3b
#undef  mxZibQpjSf_AOD3jmPGJP 
#undef  mWS0l2yfh5tQxgJsAtrrj 
#undef mGQi_qk5WqGxfw3hwI9kysgUEhfsfzm
#undef mgHnIWDnr_sVbFTpC7AbxU3m7wfatv9
#undef mHn7kCxr1u8OzJRv9VDOs8iMaWDQJEt
#undef mNCNdYP5LuJnsQTdM8zH_xg7vbWdC0A
#undef  mew104il0NYSBTr2jkLM3 
#undef  mF0tWhUZ7jYhY0npndtdj 
#undef  mHr0c8IVDpCDYRv1QmJGX 
#undef  mzvPczhkNi3FestNTqPlJ 
#undef mBmSsFY4sWdtFxPzOXVCAICtgEcviql
#undef mEGQpuy1WdBPM5Qpj90TGvIGQOFZVZ7
#undef  mNn5l5m8mHucLPbpklGZ6 
#undef  mPeNrpgxFQsvos7boRTS4 
#undef mrP1FCIEftYqWR9gkib0IrkL06ol4uV
#undef  miQx4Ts8eejTpnlCpub57 
#undef  mFc8UPJY_sAkdHNDXdkof 
#undef  mpOErO57m42oxHSYvVnPc 
#undef  mE08Lwn9gDaYvYQqVUYeX 
#undef  mR1MQ9NFPFGBLy3C4R9kb 
#undef  mlNZmUVik60CojLKtMrW4 
#undef  mMQcmuvz0E4KOpx6dTyhQ 
#undef  mENaUsQQS8MUXImic160m 
#undef  mGGDcwT69bth2k4iGct2s 
#undef  mDrFXd2It5NtCbw99INn8 
#undef  mlGNWDac1jhg0IVgJz0cp 
#undef  mCXWyrMT0nStnTJ7VCTN6 
#undef  mBE1TPOXEhd7rPBULoreV 
#undef  mLmr5j32YSn8vyKJW8FU2 
#undef mn8gEs83cmjjyP1XzbkmYBXnkkdUT4S
#undef  mZb7KTNqRjbrZZ5axEwDO 
#undef  mcfbf07CtFrNHy19avTe7 
#undef  mFWWl6FqRAEMB3hS6zK1G 
#undef  mMTaoT0bnF8UlKG7aMzat 
#undef  mLJyEHkT09WcKZznAtzCu 
#undef  mjrKOky754v3VDLQI3ZmQ 
#undef  mfW4UYWlxe2W8JjcFcHTR 
#undef  m_gXYC3n2Y1RTTfjeZt_u 
#undef  mERlVJBFRsn1YUIm8p02R 
#undef  mEAZQrItLUCDHrszPKSxF 
#undef  mQ8uKgI7q7sRoMsoRyDeT 
#undef  mJDqhxfoCmLYCFWsqAfx2 
#undef mpRuNQ3hNrDN6o2YeUWGbMhVXNdR490
#undef  mNATppPm7DtGekq2MA6SG 
#undef mBCit1X3WJxIbexm4z1mr3sYE0beEa3
#undef  mkUi0Q077KNfre5zkr8F7 
#undef  mncnzm31WHdNlRf2U2bZy 
#undef  mkytqmjOjVRbus820IYdY 
#undef  mp8EGSclPMYLYFKKmiHx3 
#undef  mNXbChB88oEum_NQflupx 
#undef  mem4uNX6UWLQ4lH4i4iQF 
#undef  mOGyjn5Lwrb8_TUemaTsS 
#undef  ms4ph9zt0bTB7CFzE6o86 
#undef  mCe2bTSECRODRcHrk5KZ2 
#undef  mxJDzFfbe2NroTyZmjvRo 
#undef  mIAn9y8vdwFhMXE3wn9Hb 
#undef  mGx5njZFaeVm7LJtrE4W3 
#undef mn9EePcLH3V6dIIW5459tSHWqLCS4tL
#undef  mkmWjQGfeAZT4KIyfhDDH 
#undef  ma5uM4HTKoUcKkUF9iK7h 
#undef  mZZvCH8rp_rJBuLAUjdAZ 
#undef  mpUhEDQMoQCPhrc0_prAH 
#undef  mLr4TipRZNRQuIWvesjNZ 
#undef  mwG3BsdPMi9YwJcz6hZmA 
#undef mq4Il57K46fnzV5eQ3x4wBfqn7O6eOn
#undef  mW6uoCq9U1n6mWNb3P0NC 
#undef  mo97BVmLVPN_h2z5qt5ZO 
#undef  mDWXx7cSigayBG0wCPA2l 
#undef  mXmNXoXFTh2ufYfh9I6MS 
#endif
